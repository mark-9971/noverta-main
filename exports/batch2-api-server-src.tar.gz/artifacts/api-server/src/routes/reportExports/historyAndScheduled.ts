// tenant-scope: district-join
import { randomBytes } from "node:crypto";
import { Router, type Request, type Response } from "express";
import { db } from "@workspace/db";
import {
  exportHistoryTable, scheduledReportsTable,
} from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import type { SQL } from "drizzle-orm";
import type { AuthedRequest } from "../../middlewares/auth";
import { logAudit } from "../../lib/auditLog";
import { resolveExportScope, buildCSV, fmtDate, type ReportFilters, ROLE_LABELS, initPdfDoc, pdfHeader, pdfTableHeader, pdfTableRow, pdfFooters, csvAddDemoDisclaimer } from "./utils";
import { isDistrictDemo } from "../../lib/districtMode";
import {
  fetchComplianceSummaryData,
  fetchStudentRosterData,
  fetchProviderSessionData,
  fetchCaseloadData,
} from "./fetchers";

const router = Router();

router.get("/reports/exports/history", async (req: Request, res: Response): Promise<void> => {
  try {
    const scope = resolveExportScope(req);
    if ("error" in scope) { res.status(scope.status).json({ error: scope.error }); return; }

    const conditions: SQL[] = [];
    if (scope.enforcedDistrictId !== null) {
      conditions.push(eq(exportHistoryTable.districtId, scope.enforcedDistrictId));
    }

    const history = await db.select({
      id: exportHistoryTable.id,
      reportType: exportHistoryTable.reportType,
      reportLabel: exportHistoryTable.reportLabel,
      format: exportHistoryTable.format,
      fileName: exportHistoryTable.fileName,
      recordCount: exportHistoryTable.recordCount,
      exportedBy: exportHistoryTable.exportedBy,
      createdAt: exportHistoryTable.createdAt,
    }).from(exportHistoryTable)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(exportHistoryTable.createdAt))
      .limit(50);

    res.json(history);
  } catch (e: any) {
    console.error("GET /reports/exports/history error:", e);
    res.status(500).json({ error: "Failed to fetch export history" });
  }
});

router.get("/reports/exports/history/:id/download", async (req: Request, res: Response): Promise<void> => {
  try {
    const id = parseInt(req.params.id as string, 10);
    if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

    const scope = resolveExportScope(req);
    if ("error" in scope) { res.status(scope.status).json({ error: scope.error }); return; }

    const conditions: ReturnType<typeof eq>[] = [eq(exportHistoryTable.id, id)];
    if (scope.enforcedDistrictId !== null) {
      conditions.push(eq(exportHistoryTable.districtId, scope.enforcedDistrictId));
    }

    const [entry] = await db.select().from(exportHistoryTable).where(and(...conditions));
    if (!entry) { res.status(404).json({ error: "Export not found" }); return; }

    const validTypes = ["compliance-summary", "services-by-provider", "student-roster", "caseload-distribution"];
    if (!validTypes.includes(entry.reportType)) {
      res.status(400).json({ error: "Report type does not support regeneration" });
      return;
    }

    if (entry.format !== "csv" && entry.format !== "pdf") {
      res.status(400).json({ error: "Re-download is only supported for CSV and PDF exports" });
      return;
    }

    const params = (entry.parameters as Record<string, unknown>) ?? {};
    const reportFilters: ReportFilters = {
      startDate: params.start as string | undefined,
      endDate: params.end as string | undefined,
      schoolId: params.schoolId ? Number(params.schoolId) : undefined,
      providerId: params.providerId ? Number(params.providerId) : undefined,
      serviceTypeId: params.serviceTypeId ? Number(params.serviceTypeId) : undefined,
      complianceStatus: params.complianceStatus as string | undefined,
    };

    const effectiveDistrictId = entry.districtId ?? scope.enforcedDistrictId;
    if (!effectiveDistrictId || effectiveDistrictId <= 0) {
      res.status(400).json({ error: "Cannot regenerate report without a valid district scope" });
      return;
    }
    const [isHistoryDemo, result] = await Promise.all([
      isDistrictDemo(effectiveDistrictId),
      generateReportCSVDirect(entry.reportType, effectiveDistrictId, reportFilters),
    ]);
    if (!result) { res.status(500).json({ error: "Failed to regenerate report" }); return; }

    if (entry.format === "pdf") {
      const frequency = (params.frequency as string | undefined) ?? "scheduled";
      let html = buildScheduledReportHtml({
        label: entry.reportLabel,
        headers: result.headers,
        rows: result.rows,
        frequency,
      });
      if (isHistoryDemo) {
        html = html.replace(
          "<body>",
          `<body><div style="background:#fef3c7;color:#92400e;font-weight:bold;text-align:center;padding:8px;font-family:sans-serif;font-size:13px;margin-bottom:12px;">SAMPLE DATA — NOT REAL STUDENT RECORDS</div>`,
        );
      }
      const baseName = (entry.fileName || `${entry.reportType}.pdf`).replace(/\.pdf$/i, ".html");
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="${baseName}"`);
      res.send(html);
      return;
    }

    const filename = entry.fileName || `${entry.reportType}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.send(isHistoryDemo ? csvAddDemoDisclaimer(result.csv) : result.csv);
  } catch (e: unknown) {
    console.error("GET /reports/exports/history/:id/download error:", e);
    res.status(500).json({ error: "Failed to regenerate report" });
  }
});

router.get("/reports/exports/scheduled", async (req: Request, res: Response): Promise<void> => {
  try {
    const scope = resolveExportScope(req);
    if ("error" in scope) { res.status(scope.status).json({ error: scope.error }); return; }

    const conditions: SQL[] = [];
    if (scope.enforcedDistrictId !== null) {
      conditions.push(eq(scheduledReportsTable.districtId, scope.enforcedDistrictId));
    }

    const schedules = await db.select().from(scheduledReportsTable)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(scheduledReportsTable.createdAt));

    res.json(schedules);
  } catch (e: any) {
    console.error("GET /reports/exports/scheduled error:", e);
    res.status(500).json({ error: "Failed to fetch scheduled reports" });
  }
});

router.post("/reports/exports/scheduled", async (req: Request, res: Response): Promise<void> => {
  try {
    const scope = resolveExportScope(req);
    if ("error" in scope) { res.status(scope.status).json({ error: scope.error }); return; }

    const { reportType, frequency, filters, recipientEmails, format } = req.body;

    if (!reportType || !frequency || !recipientEmails || !Array.isArray(recipientEmails) || recipientEmails.length === 0) {
      res.status(400).json({ error: "Missing required fields: reportType, frequency, recipientEmails" });
      return;
    }

    const validReportTypes = ["compliance-summary", "services-by-provider", "student-roster", "caseload-distribution", "executive-summary"];
    if (!validReportTypes.includes(reportType)) {
      res.status(400).json({ error: `Invalid reportType. Must be one of: ${validReportTypes.join(", ")}` });
      return;
    }

    const validFreqs = ["weekly", "monthly"];
    if (!validFreqs.includes(frequency)) {
      res.status(400).json({ error: `Invalid frequency. Must be one of: ${validFreqs.join(", ")}` });
      return;
    }

    // The executive-summary type is always emailed as a PDF — it has no CSV
    // representation. Other report types default to CSV and may opt in to PDF.
    const resolvedFormat: "csv" | "pdf" =
      reportType === "executive-summary" ? "pdf" : (format === "pdf" ? "pdf" : "csv");
    const validFormats = ["csv", "pdf"];
    if (format && !validFormats.includes(format)) {
      res.status(400).json({ error: `Invalid format. Must be one of: ${validFormats.join(", ")}` });
      return;
    }

    const validRecipients = (recipientEmails as unknown[]).every(
      e => typeof e === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)
    );
    if (!validRecipients) {
      res.status(400).json({ error: "recipientEmails must be valid email addresses" });
      return;
    }

    if (scope.enforcedDistrictId === null) {
      res.status(400).json({ error: "District scope is required to create scheduled reports. Platform admins must specify a district." });
      return;
    }
    const districtId = scope.enforcedDistrictId;
    const createdBy = (req as unknown as AuthedRequest).userId ?? "system";

    const now = new Date();
    let nextRunAt: Date;
    if (frequency === "weekly") {
      nextRunAt = new Date(now);
      nextRunAt.setDate(nextRunAt.getDate() + (7 - nextRunAt.getDay()) % 7 + 1);
      nextRunAt.setHours(6, 0, 0, 0);
    } else {
      nextRunAt = new Date(now.getFullYear(), now.getMonth() + 1, 1, 6, 0, 0, 0);
    }

    const unsubscribeSecret = randomBytes(24).toString("hex");

    const [created] = await db.insert(scheduledReportsTable).values({
      districtId,
      reportType,
      frequency,
      format: resolvedFormat,
      filters: filters ?? {},
      recipientEmails,
      unsubscribeSecret,
      createdBy,
      nextRunAt,
    }).returning();

    logAudit(req, { action: "create", targetTable: "scheduled_reports", targetId: created.id, summary: `Created scheduled ${frequency} ${resolvedFormat.toUpperCase()} report: ${reportType}` });

    res.status(201).json(created);
  } catch (e: any) {
    console.error("POST /reports/exports/scheduled error:", e);
    res.status(500).json({ error: "Failed to create scheduled report" });
  }
});

router.patch("/reports/exports/scheduled/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const id = parseInt(req.params.id as string, 10);
    if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

    const scope = resolveExportScope(req);
    if ("error" in scope) { res.status(scope.status).json({ error: scope.error }); return; }

    const { frequency, format, recipientEmails, filters } = req.body ?? {};

    const updates: Partial<typeof scheduledReportsTable.$inferInsert> = {};

    if (frequency !== undefined) {
      const validFreqs = ["weekly", "monthly"];
      if (!validFreqs.includes(frequency)) {
        res.status(400).json({ error: `Invalid frequency. Must be one of: ${validFreqs.join(", ")}` });
        return;
      }
      updates.frequency = frequency;
    }

    if (format !== undefined) {
      const validFormats = ["csv", "pdf"];
      if (!validFormats.includes(format)) {
        res.status(400).json({ error: `Invalid format. Must be one of: ${validFormats.join(", ")}` });
        return;
      }
      updates.format = format;
    }

    if (recipientEmails !== undefined) {
      if (!Array.isArray(recipientEmails) || recipientEmails.length === 0) {
        res.status(400).json({ error: "recipientEmails must be a non-empty array" });
        return;
      }
      updates.recipientEmails = recipientEmails;
    }

    if (filters !== undefined) {
      updates.filters = filters ?? {};
    }

    if (Object.keys(updates).length === 0) {
      res.status(400).json({ error: "No editable fields provided" });
      return;
    }

    const conditions: SQL[] = [eq(scheduledReportsTable.id, id)];
    if (scope.enforcedDistrictId !== null) {
      conditions.push(eq(scheduledReportsTable.districtId, scope.enforcedDistrictId));
    }

    const [updated] = await db.update(scheduledReportsTable)
      .set(updates)
      .where(and(...conditions))
      .returning();

    if (!updated) { res.status(404).json({ error: "Scheduled report not found" }); return; }

    logAudit(req, { action: "update", targetTable: "scheduled_reports", targetId: id, summary: `Updated scheduled report ${id}` });
    res.json(updated);
  } catch (e: any) {
    console.error("PATCH /reports/exports/scheduled error:", e);
    res.status(500).json({ error: "Failed to update scheduled report" });
  }
});

router.delete("/reports/exports/scheduled/:id", async (req: Request, res: Response): Promise<void> => {
  try {
    const id = parseInt(req.params.id as string, 10);
    if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

    const scope = resolveExportScope(req);
    if ("error" in scope) { res.status(scope.status).json({ error: scope.error }); return; }

    const conditions: SQL[] = [eq(scheduledReportsTable.id, id)];
    if (scope.enforcedDistrictId !== null) {
      conditions.push(eq(scheduledReportsTable.districtId, scope.enforcedDistrictId));
    }

    const deleted = await db.delete(scheduledReportsTable).where(and(...conditions)).returning();
    if (deleted.length === 0) { res.status(404).json({ error: "Scheduled report not found" }); return; }

    logAudit(req, { action: "delete", targetTable: "scheduled_reports", targetId: id, summary: `Deleted scheduled report ${id}` });
    res.json({ success: true });
  } catch (e: any) {
    console.error("DELETE /reports/exports/scheduled error:", e);
    res.status(500).json({ error: "Failed to delete scheduled report" });
  }
});

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

export function buildScheduledReportHtml(opts: {
  label: string;
  headers: string[];
  rows: (string | number | null | undefined)[][];
  frequency: string;
}): string {
  const { label, headers, rows, frequency } = opts;
  const dateStr = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  const subtitle = `Scheduled ${frequency} report — ${dateStr} — ${rows.length} record${rows.length !== 1 ? "s" : ""}`;
  const headerRow = headers.map(h => `<th>${escapeHtml(h)}</th>`).join("");
  const bodyRows = rows.length === 0
    ? `<tr><td colspan="${Math.max(1, headers.length)}" class="empty">No records found for this report period.</td></tr>`
    : rows.map(r => `<tr>${headers.map((_, i) => `<td>${escapeHtml(String(r[i] ?? ""))}</td>`).join("")}</tr>`).join("");
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${escapeHtml(label)}</title>
<style>
  @page { size: letter; margin: 0.5in; }
  body { font-family: Helvetica, Arial, sans-serif; color: #111827; margin: 24px; }
  h1 { font-size: 18px; margin: 0 0 4px 0; }
  .subtitle { font-size: 11px; color: #6b7280; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; font-size: 11px; }
  th { background: #f3f4f6; text-align: left; padding: 6px 8px; border-bottom: 1px solid #d1d5db; }
  td { padding: 5px 8px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
  td.empty { text-align: center; color: #6b7280; padding: 20px; }
  @media print { body { margin: 0; } }
</style>
</head>
<body>
  <h1>${escapeHtml(label)}</h1>
  <div class="subtitle">${escapeHtml(subtitle)}</div>
  <table>
    <thead><tr>${headerRow}</tr></thead>
    <tbody>${bodyRows}</tbody>
  </table>
</body>
</html>`;
}

export async function buildScheduledReportPdf(opts: {
  label: string;
  headers: string[];
  rows: (string | number | null | undefined)[][];
  frequency: string;
  isDemo?: boolean;
}): Promise<Buffer> {
  const { label, headers, rows, frequency, isDemo } = opts;
  const doc = initPdfDoc();

  const chunks: Buffer[] = [];
  doc.on("data", (chunk: Buffer) => chunks.push(chunk));

  const dateStr = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  pdfHeader(doc, label, `Scheduled ${frequency} report — ${dateStr} — ${rows.length} record${rows.length !== 1 ? "s" : ""}`);

  if (isDemo) {
    const bannerY = doc.y;
    doc.rect(60, bannerY, 492, 20).fill("#fef3c7");
    doc.fontSize(9).font("Helvetica-Bold").fillColor("#92400e")
      .text("SAMPLE DATA — NOT REAL STUDENT RECORDS", 60, bannerY + 6, { width: 492, align: "center" });
    doc.y = bannerY + 24;
    doc.moveDown(0.3);
  }

  const totalWidth = 492;
  const colCount = Math.max(1, headers.length);
  const colWidth = Math.floor(totalWidth / colCount);
  const lastColWidth = totalWidth - colWidth * (colCount - 1);
  const cols = headers.map((h, i) => ({ text: h, width: i === colCount - 1 ? lastColWidth : colWidth }));

  if (rows.length > 0) {
    pdfTableHeader(doc, cols);
    for (const row of rows) {
      if (doc.y > 700) { doc.addPage(); pdfTableHeader(doc, cols); }
      const y = doc.y;
      pdfTableRow(doc, cols.map((c, i) => ({ text: String(row[i] ?? ""), width: c.width })), y);
      doc.y = y + 13;
    }
  } else {
    doc.font("Helvetica").fontSize(9).fillColor("#6b7280").text("No records found for this report period.", { align: "center" });
  }

  pdfFooters(doc, label);

  return new Promise<Buffer>((resolve, reject) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
    doc.end();
  });
}

export async function generateReportCSVDirect(reportType: string, districtId: number, filters?: ReportFilters): Promise<{ csv: string; rowCount: number; headers: string[]; rows: (string | number | null | undefined)[][] } | null> {
  if (districtId <= 0) {
    console.error(`[generateReportCSVDirect] Refusing to generate report without valid district scope (districtId=${districtId})`);
    return null;
  }
  try {
    if (reportType === "compliance-summary") {
      const now = new Date();
      const start = filters?.startDate || new Date(now.getFullYear(), now.getMonth() - 3, 1).toISOString().split("T")[0];
      const end = filters?.endDate || now.toISOString().split("T")[0];

      const { students, reqsByStudent, sessionMap } = await fetchComplianceSummaryData(districtId, {
        start,
        end,
        schoolId: filters?.schoolId ?? null,
        serviceTypeId: filters?.serviceTypeId ?? null,
      });

      const headers = ["Student", "School", "Grade", "Service", "Required", "Delivered", "Compliance %", "Status"];
      if (students.length === 0) return { csv: buildCSV(headers, []), rowCount: 0, headers, rows: [] };

      const complianceMapping: Record<string, string> = { "compliant": "On Track", "at-risk": "At Risk", "non-compliant": "Out of Compliance" };
      const rows: (string | number)[][] = [];
      for (const student of students) {
        for (const r of (reqsByStudent.get(student.id) ?? [])) {
          const key = `${student.id}|${r.serviceTypeName ?? ""}`;
          const sm = sessionMap.get(key) ?? { delivered: 0, completed: 0, missed: 0 };
          const total = sm.completed + sm.missed;
          const pct = total > 0 ? Math.round((sm.completed / total) * 100) : 100;
          const status = pct >= 90 ? "On Track" : pct >= 75 ? "At Risk" : "Out of Compliance";
          if (filters?.complianceStatus && complianceMapping[filters.complianceStatus] && status !== complianceMapping[filters.complianceStatus]) continue;
          rows.push([`${student.lastName}, ${student.firstName}`, student.schoolName ?? "", student.grade ?? "", r.serviceTypeName ?? "", `${r.requiredMinutes ?? ""}/${r.intervalType ?? "week"}`, sm.delivered, `${pct}%`, status]);
        }
      }
      return { csv: buildCSV(headers, rows), rowCount: rows.length, headers, rows };
    }

    if (reportType === "student-roster") {
      const { students } = await fetchStudentRosterData(districtId, {
        schoolId: filters?.schoolId ?? null,
        statusFilter: "active",
      });
      const headers = ["Last Name", "First Name", "Grade", "School", "Status", "Disability", "Placement", "DOB", "Enrolled"];
      const rows = students.map(s => [s.lastName, s.firstName, s.grade ?? "", s.schoolName ?? "", s.status ?? "", s.disabilityCategory ?? "", s.placementType ?? "", fmtDate(s.dateOfBirth), fmtDate(s.enrolledAt)]);
      return { csv: buildCSV(headers, rows), rowCount: rows.length, headers, rows };
    }

    if (reportType === "services-by-provider") {
      const now = new Date();
      const start = filters?.startDate || new Date(now.getFullYear(), now.getMonth() - 3, 1).toISOString().split("T")[0];
      const end = filters?.endDate || now.toISOString().split("T")[0];

      const { staffMembers, sessionData } = await fetchProviderSessionData(districtId, {
        start,
        end,
        schoolId: filters?.schoolId ?? null,
        providerId: filters?.providerId ?? null,
        serviceTypeId: filters?.serviceTypeId ?? null,
      });

      const providerMap = new Map<string, { completed: number; missed: number; minutes: number; students: Set<number> }>();
      for (const s of sessionData) {
        const key = `${s.staffId}|${s.serviceTypeName ?? "Other"}`;
        if (!providerMap.has(key)) providerMap.set(key, { completed: 0, missed: 0, minutes: 0, students: new Set() });
        const e = providerMap.get(key)!;
        if (s.status === "completed" || s.status === "makeup") { e.completed++; e.minutes += s.durationMinutes ?? 0; } else if (s.status === "missed") e.missed++;
        if (s.studentId) e.students.add(s.studentId);
      }
      const staffLookup = new Map(staffMembers.map(s => [s.id, s]));
      const headers = ["Provider", "Role", "School", "Service Type", "Sessions Completed", "Missed", "Total Minutes", "Students"];
      const rows: (string | number)[][] = [];
      for (const [key, data] of providerMap) {
        const [staffIdStr, serviceType] = key.split("|");
        const staff = staffLookup.get(Number(staffIdStr));
        if (!staff) continue;
        rows.push([`${staff.lastName}, ${staff.firstName}`, ROLE_LABELS[staff.role] ?? staff.role, staff.schoolName ?? "", serviceType, data.completed, data.missed, data.minutes, data.students.size]);
      }
      return { csv: buildCSV(headers, rows), rowCount: rows.length, headers, rows };
    }

    if (reportType === "caseload-distribution") {
      const { staffMembers, assignments } = await fetchCaseloadData(districtId, {
        schoolId: filters?.schoolId ?? null,
      });

      const caseloadMap = new Map<number, Set<number>>();
      for (const a of assignments) {
        if (!caseloadMap.has(a.staffId)) caseloadMap.set(a.staffId, new Set());
        caseloadMap.get(a.staffId)!.add(a.studentId);
      }
      const headers = ["Staff Member", "Role", "School", "Caseload Size"];
      const rows: (string | number)[][] = staffMembers.map(s => [`${s.lastName}, ${s.firstName}`, ROLE_LABELS[s.role] ?? s.role, s.schoolName ?? "", caseloadMap.get(s.id)?.size ?? 0]);
      return { csv: buildCSV(headers, rows), rowCount: rows.length, headers, rows };
    }

    return null;
  } catch (e) {
    console.error(`[generateReportCSVDirect] Error generating ${reportType}:`, e);
    return null;
  }
}

export default router;
