import { Router, type IRouter, type Request } from "express";
import { db } from "@workspace/db";
import { getEnforcedDistrictId } from "../../middlewares/auth";
import type { AuthedRequest } from "../../middlewares/auth";
import {
  studentsTable, sessionLogsTable, serviceTypesTable,
  serviceRequirementsTable, iepDocumentsTable, alertsTable,
  generatedDocumentsTable,
} from "@workspace/db";
import { GetExecutiveSummaryReportQueryParams } from "@workspace/api-zod";
import { eq, and, gte, lte, sql, count, isNull } from "drizzle-orm";
import { requireReportExport } from "./shared";
import { recordExport } from "../reportExports/utils";
import { z } from "zod";
import { logAudit } from "../../lib/auditLog";
import { sanitizeHtmlSnapshot } from "../generatedDocuments";

const router: IRouter = Router();

export interface ExecutiveSummaryOptions {
  districtId: number | null;
  schoolId?: number | null;
  schoolYearId?: number | null;
  startDate?: string;
  endDate?: string;
  preparedBy?: string | null;
}

export interface ExecutiveSummaryResult {
  generatedAt: string;
  preparedBy: string | null;
  totalActiveStudents: number;
  complianceRate: number;
  riskCounts: { onTrack: number; slightlyBehind: number; atRisk: number; outOfCompliance: number };
  serviceDelivery: {
    totalDeliveredMinutes: number;
    totalRequiredMinutes: number;
    overallPercent: number;
    totalMissedSessions: number;
    totalMakeupSessions: number;
    byService: { serviceTypeName: string; deliveredMinutes: number; requiredMinutes: number; percentComplete: number; studentCount: number }[];
  };
  iepDeadlines: { within30: number; within60: number; within90: number; overdue: number };
  alerts: { openAlerts: number; criticalAlerts: number };
  reportPeriod: { start: string; end: string };
}

export async function computeExecutiveSummary(opts: ExecutiveSummaryOptions): Promise<ExecutiveSummaryResult> {
  const districtId = opts.districtId !== null ? String(opts.districtId) : null;
  const schoolId = opts.schoolId ?? null;
  const execYearId = opts.schoolYearId ?? null;
  const now = new Date();
  const start = opts.startDate || new Date(now.getFullYear(), now.getMonth() - 6, 1).toISOString().split("T")[0];
  const end = opts.endDate || now.toISOString().split("T")[0];

  const studentConditions: ReturnType<typeof eq>[] = [eq(studentsTable.status, "active") as ReturnType<typeof eq>];
  if (schoolId) studentConditions.push(eq(studentsTable.schoolId, Number(schoolId)) as ReturnType<typeof eq>);
  if (districtId) studentConditions.push(sql`${studentsTable.schoolId} IN (SELECT id FROM schools WHERE district_id = ${Number(districtId)})` as ReturnType<typeof eq>);

  const activeStudents = await db.select({ id: studentsTable.id }).from(studentsTable).where(and(...studentConditions));
  const studentIds = activeStudents.map(s => s.id);
  if (studentIds.length === 0) {
    return {
      generatedAt: new Date().toISOString(),
      preparedBy: opts.preparedBy ?? null,
      totalActiveStudents: 0, complianceRate: 100,
      riskCounts: { onTrack: 0, slightlyBehind: 0, atRisk: 0, outOfCompliance: 0 },
      serviceDelivery: { totalDeliveredMinutes: 0, totalRequiredMinutes: 0, overallPercent: 100, totalMissedSessions: 0, totalMakeupSessions: 0, byService: [] },
      iepDeadlines: { within30: 0, within60: 0, within90: 0, overdue: 0 },
      alerts: { openAlerts: 0, criticalAlerts: 0 },
      reportPeriod: { start, end },
    };
  }

  const requirements = await db.select({
    id: serviceRequirementsTable.id,
    studentId: serviceRequirementsTable.studentId,
    serviceTypeId: serviceRequirementsTable.serviceTypeId,
    requiredMinutes: serviceRequirementsTable.requiredMinutes,
    intervalType: serviceRequirementsTable.intervalType,
    serviceTypeName: serviceTypesTable.name,
  })
    .from(serviceRequirementsTable)
    .leftJoin(serviceTypesTable, eq(serviceTypesTable.id, serviceRequirementsTable.serviceTypeId))
    .where(and(
      eq(serviceRequirementsTable.active, true),
      sql`${serviceRequirementsTable.studentId} IN (${sql.join(studentIds.map(id => sql`${id}`), sql`, `)})`
    ));

  const sessions = await db.select({
    studentId: sessionLogsTable.studentId,
    serviceRequirementId: sessionLogsTable.serviceRequirementId,
    durationMinutes: sessionLogsTable.durationMinutes,
    status: sessionLogsTable.status,
    isMakeup: sessionLogsTable.isMakeup,
  })
    .from(sessionLogsTable)
    .where(and(
      gte(sessionLogsTable.sessionDate, start),
      lte(sessionLogsTable.sessionDate, end),
      sql`${sessionLogsTable.studentId} IN (${sql.join(studentIds.map(id => sql`${id}`), sql`, `)})`,
      isNull(sessionLogsTable.deletedAt),
      ...(execYearId ? [eq(sessionLogsTable.schoolYearId, Number(execYearId))] : [])
    ));

  function normalizeToRange(requiredMinutes: number, intervalType: string): number {
    const startD = new Date(start + "T12:00:00");
    const endD = new Date(end + "T12:00:00");
    const rangeDays = Math.max(1, (endD.getTime() - startD.getTime()) / 86400000);
    const rangeWeeks = rangeDays / 7;
    const rangeMonths = rangeDays / 30.44;
    if (intervalType === "weekly") return requiredMinutes * rangeWeeks;
    if (intervalType === "monthly") return requiredMinutes * rangeMonths;
    if (intervalType === "quarterly") return requiredMinutes * (rangeMonths / 3);
    return requiredMinutes * rangeWeeks;
  }

  const reqByStudent = new Map<number, { required: number; delivered: number; missed: number; makeup: number }>();
  const serviceDelivery: Record<string, { delivered: number; required: number; students: Set<number> }> = {};

  for (const r of requirements) {
    const rangeReq = normalizeToRange(r.requiredMinutes, r.intervalType);
    if (!reqByStudent.has(r.studentId)) reqByStudent.set(r.studentId, { required: 0, delivered: 0, missed: 0, makeup: 0 });
    reqByStudent.get(r.studentId)!.required += rangeReq;
    const svcName = r.serviceTypeName ?? "Unknown";
    if (!serviceDelivery[svcName]) serviceDelivery[svcName] = { delivered: 0, required: 0, students: new Set() };
    serviceDelivery[svcName].required += rangeReq;
    serviceDelivery[svcName].students.add(r.studentId);
  }

  for (const s of sessions) {
    const entry = reqByStudent.get(s.studentId);
    if (!entry) continue;
    if (s.status === "completed" || s.status === "makeup") entry.delivered += s.durationMinutes;
    if (s.status === "missed") entry.missed++;
    if (s.isMakeup) entry.makeup++;
    const req = requirements.find(r => r.id === s.serviceRequirementId);
    if (req) {
      const svcName = req.serviceTypeName ?? "Unknown";
      if (serviceDelivery[svcName] && (s.status === "completed" || s.status === "makeup")) {
        serviceDelivery[svcName].delivered += s.durationMinutes;
      }
    }
  }

  const riskCounts = { onTrack: 0, slightlyBehind: 0, atRisk: 0, outOfCompliance: 0 };
  let totalDelivered = 0, totalRequired = 0, totalMissed = 0, totalMakeup = 0;
  for (const [, entry] of reqByStudent) {
    totalDelivered += entry.delivered;
    totalRequired += entry.required;
    totalMissed += entry.missed;
    totalMakeup += entry.makeup;
    const pct = entry.required > 0 ? entry.delivered / entry.required : 1;
    if (pct >= 0.95) riskCounts.onTrack++;
    else if (pct >= 0.85) riskCounts.slightlyBehind++;
    else if (pct >= 0.70) riskCounts.atRisk++;
    else riskCounts.outOfCompliance++;
  }
  const totalTracked = riskCounts.onTrack + riskCounts.slightlyBehind + riskCounts.atRisk + riskCounts.outOfCompliance;
  const complianceRate = totalTracked > 0 ? Math.round((riskCounts.onTrack / totalTracked) * 100) : 100;

  const serviceBreakdown = Object.entries(serviceDelivery).map(([name, d]) => ({
    serviceTypeName: name,
    deliveredMinutes: Math.round(d.delivered),
    requiredMinutes: Math.round(d.required),
    percentComplete: d.required > 0 ? Math.round((d.delivered / d.required) * 100) : 100,
    studentCount: d.students.size,
  }));

  const iepConditions: any[] = [eq(iepDocumentsTable.active, true)];
  if (schoolId) iepConditions.push(sql`${iepDocumentsTable.studentId} IN (SELECT id FROM students WHERE school_id = ${Number(schoolId)})`);
  if (districtId) iepConditions.push(sql`${iepDocumentsTable.studentId} IN (SELECT id FROM students WHERE school_id IN (SELECT id FROM schools WHERE district_id = ${Number(districtId)}))`);

  const iepDocs = await db.select({ iepEndDate: iepDocumentsTable.iepEndDate })
    .from(iepDocumentsTable).where(and(...iepConditions));

  const todayMs = Date.now();
  const deadlines = { within30: 0, within60: 0, within90: 0, overdue: 0 };
  for (const doc of iepDocs) {
    const days = Math.ceil((new Date(doc.iepEndDate).getTime() - todayMs) / 86400000);
    if (days < 0) deadlines.overdue++;
    else if (days <= 30) deadlines.within30++;
    else if (days <= 60) deadlines.within60++;
    else if (days <= 90) deadlines.within90++;
  }

  const alertConditions: any[] = [eq(alertsTable.resolved, false)];
  if (schoolId) alertConditions.push(sql`${alertsTable.studentId} IN (SELECT id FROM students WHERE school_id = ${Number(schoolId)})`);
  if (districtId) alertConditions.push(sql`${alertsTable.studentId} IN (SELECT id FROM students WHERE school_id IN (SELECT id FROM schools WHERE district_id = ${Number(districtId)}))`);

  const [alertResult] = await db.select({
    total: count(),
    critical: sql<number>`count(*) filter (where ${alertsTable.severity} = 'critical')`,
  }).from(alertsTable).where(and(...alertConditions));

  return {
    generatedAt: new Date().toISOString(),
    preparedBy: opts.preparedBy ?? null,
    totalActiveStudents: activeStudents.length,
    complianceRate,
    riskCounts,
    serviceDelivery: {
      totalDeliveredMinutes: Math.round(totalDelivered),
      totalRequiredMinutes: Math.round(totalRequired),
      overallPercent: totalRequired > 0 ? Math.round((totalDelivered / totalRequired) * 100) : 100,
      totalMissedSessions: totalMissed,
      totalMakeupSessions: totalMakeup,
      byService: serviceBreakdown,
    },
    iepDeadlines: deadlines,
    alerts: {
      openAlerts: alertResult?.total ?? 0,
      criticalAlerts: alertResult?.critical ?? 0,
    },
    reportPeriod: { start, end },
  };
}

const RecordExecSummaryBody = z.object({
  schoolId: z.union([z.number().int().positive(), z.string()]).optional(),
  schoolYearId: z.union([z.number().int().positive(), z.string()]).optional(),
  districtName: z.string().max(500).optional(),
  schoolYear: z.string().max(100).optional(),
  complianceRate: z.number().optional(),
  studentsServed: z.number().int().nonnegative().optional(),
  generatedAt: z.string().optional(),
  htmlSnapshot: z.string().max(2_000_000).optional(),
});

router.post("/reports/executive-summary/record-export", requireReportExport, async (req: Request, res): Promise<void> => {
  const parsed = RecordExecSummaryBody.safeParse(req.body ?? {});
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid body", details: parsed.error.flatten() });
    return;
  }
  const authed = req as unknown as AuthedRequest;
  const districtId = getEnforcedDistrictId(authed);
  if (!districtId) {
    res.status(400).json({ error: "District scope is required to record executive summaries" });
    return;
  }

  const { schoolId, schoolYearId, districtName, schoolYear, complianceRate, studentsServed, generatedAt, htmlSnapshot } = parsed.data;
  const dateLabel = (() => {
    try { return new Date(generatedAt ?? Date.now()).toISOString().split("T")[0]; }
    catch { return new Date().toISOString().split("T")[0]; }
  })();
  const safeDistrict = (districtName ?? "District").replace(/[^A-Za-z0-9_-]+/g, "_").slice(0, 60) || "District";
  const fileName = `Executive_Summary_${safeDistrict}_${dateLabel}.pdf`;
  const recordCount = typeof studentsServed === "number" ? studentsServed : 0;
  const friendlyDate = (() => {
    try {
      return new Date(generatedAt ?? Date.now()).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
    } catch { return dateLabel; }
  })();
  const title = `Executive Summary — ${districtName ?? "District"} — ${friendlyDate}`;

  let docId: number | null = null;
  try {
    const [doc] = await db
      .insert(generatedDocumentsTable)
      .values({
        studentId: null,
        districtId,
        type: "executive_summary",
        status: "finalized",
        title,
        htmlSnapshot: htmlSnapshot ? sanitizeHtmlSnapshot(htmlSnapshot) : null,
        createdByName: authed.displayName || null,
      })
      .returning();
    docId = doc.id;
    logAudit(req, {
      action: "create",
      targetTable: "generated_documents",
      targetId: doc.id,
      summary: `Generated executive summary for ${districtName ?? "district"}`,
    });
  } catch (e) {
    console.error("Failed to insert executive_summary into generated_documents:", e);
    res.status(500).json({ error: "Failed to save generated document" });
    return;
  }

  recordExport(req, {
    reportType: "executive-summary",
    reportLabel: "Executive Summary",
    format: "pdf",
    fileName,
    recordCount,
    parameters: {
      schoolId: schoolId ?? null,
      schoolYearId: schoolYearId ?? null,
      districtName: districtName ?? null,
      schoolYear: schoolYear ?? null,
      complianceRate: typeof complianceRate === "number" ? complianceRate : null,
      generatedAt: generatedAt ?? new Date().toISOString(),
      generatedDocumentId: docId,
    },
  });
  res.status(201).json({ ok: true, id: docId, fileName, type: "executive_summary" });
});

router.get("/reports/executive-summary", requireReportExport, async (req: Request, res): Promise<void> => {
  try {
    const parsed = GetExecutiveSummaryReportQueryParams.safeParse(req.query);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid query parameters", details: parsed.error.flatten() });
      return;
    }
    const { schoolId, startDate, endDate, schoolYearId: execYearId } = req.query;
    const execEnforcedDistrictId = getEnforcedDistrictId(req as unknown as AuthedRequest);
    const result = await computeExecutiveSummary({
      districtId: execEnforcedDistrictId,
      schoolId: schoolId ? Number(schoolId) : null,
      schoolYearId: execYearId ? Number(execYearId) : null,
      startDate: startDate as string | undefined,
      endDate: endDate as string | undefined,
      preparedBy: (req.query.preparedBy as string) || null,
    });
    res.json(result);
  } catch (e: any) {
    console.error("GET /reports/executive-summary error:", e);
    res.status(500).json({ error: "Failed to generate executive summary" });
  }
});

export default router;
