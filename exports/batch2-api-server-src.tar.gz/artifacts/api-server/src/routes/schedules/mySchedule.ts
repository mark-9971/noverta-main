import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import {
  scheduleBlocksTable, staffTable, studentsTable, serviceTypesTable,
  scheduleChangeRequestsTable, schoolsTable,
} from "@workspace/db";
import { eq, and, isNull } from "drizzle-orm";
import { z } from "zod/v4";
import type { AuthedRequest } from "../../middlewares/auth";
import { requireAuth, requireRoles } from "../../middlewares/auth";
import { blockToJson } from "./shared";
import { isBlockActiveOnDate } from "../../lib/scheduleUtils";
import { sendAdminEmail, getAppBaseUrl } from "../../lib/email";

const router: IRouter = Router();

/** Admins, coordinators, and case managers can all review change requests. */
const requireReviewer = requireRoles("admin", "coordinator", "case_manager");

const CreateChangeRequestBody = z.object({
  scheduleBlockId: z.number().int().optional(),
  requestType: z.enum(["swap_time", "coverage_request", "other"]),
  notes: z.string().max(1000).optional(),
  requestedDate: z.string().optional(),
  requestedStartTime: z.string().optional(),
  requestedEndTime: z.string().optional(),
});

const ReviewChangeRequestBody = z.object({
  status: z.enum(["approved", "denied"]),
  adminNotes: z.string().max(1000).optional(),
});

/** Resolve caller's staff ID from token or dev header. */
function resolveCallerStaffId(req: AuthedRequest): number | null {
  if (req.tenantStaffId) return req.tenantStaffId;
  if (process.env.NODE_ENV !== "production") {
    const demoStaffId = req.headers["x-demo-staff-id"];
    if (typeof demoStaffId === "string" && !isNaN(Number(demoStaffId))) {
      return Number(demoStaffId);
    }
  }
  return null;
}

/** Row type returned by the change-request list query. */
interface ChangeRequestRow {
  id: number;
  staff_id: number;
  schedule_block_id: number | null;
  request_type: string;
  notes: string | null;
  requested_date: string | null;
  requested_start_time: string | null;
  requested_end_time: string | null;
  status: string;
  admin_notes: string | null;
  reviewed_by_staff_id: number | null;
  reviewed_at: Date | null;
  created_at: Date | null;
  staff_first: string | null;
  staff_last: string | null;
  staff_role: string | null;
  day_of_week: string | null;
  start_time: string | null;
  end_time: string | null;
  location: string | null;
  student_first: string | null;
  student_last: string | null;
  service_type_name: string | null;
  reviewer_first: string | null;
  reviewer_last: string | null;
}

/** Drizzle returning() shape for schedule_change_requests. */
interface ChangeRequestRecord {
  id: number;
  staffId: number;
  scheduleBlockId: number | null;
  requestType: string;
  notes: string | null;
  requestedDate: string | null;
  requestedStartTime: string | null;
  requestedEndTime: string | null;
  status: string;
  adminNotes: string | null;
  reviewedByStaffId: number | null;
  reviewedAt: Date | null;
  createdAt: Date;
}

const CHANGE_REQUEST_SELECT_SQL = `
  SELECT
    scr.id, scr.staff_id, scr.schedule_block_id, scr.request_type,
    scr.notes, scr.requested_date, scr.requested_start_time, scr.requested_end_time,
    scr.status, scr.admin_notes, scr.reviewed_by_staff_id, scr.reviewed_at, scr.created_at,
    s.first_name AS staff_first, s.last_name AS staff_last, s.role AS staff_role,
    sb.day_of_week, sb.start_time, sb.end_time, sb.location,
    stu.first_name AS student_first, stu.last_name AS student_last,
    st.name AS service_type_name,
    rev.first_name AS reviewer_first, rev.last_name AS reviewer_last
  FROM schedule_change_requests scr
  JOIN staff s ON s.id = scr.staff_id
  LEFT JOIN schedule_blocks sb ON sb.id = scr.schedule_block_id
  LEFT JOIN students stu ON stu.id = sb.student_id
  LEFT JOIN service_types st ON st.id = sb.service_type_id
  LEFT JOIN staff rev ON rev.id = scr.reviewed_by_staff_id
`;

router.get("/schedules/my-schedule", requireAuth, async (req, res): Promise<void> => {
  const authed = req as unknown as AuthedRequest;
  const staffId = resolveCallerStaffId(authed);

  if (!staffId) {
    res.status(403).json({ error: "No staff record linked to your account. Contact your administrator." });
    return;
  }

  const blocks = await db
    .select({
      id: scheduleBlocksTable.id,
      staffId: scheduleBlocksTable.staffId,
      studentId: scheduleBlocksTable.studentId,
      serviceTypeId: scheduleBlocksTable.serviceTypeId,
      dayOfWeek: scheduleBlocksTable.dayOfWeek,
      startTime: scheduleBlocksTable.startTime,
      endTime: scheduleBlocksTable.endTime,
      location: scheduleBlocksTable.location,
      blockLabel: scheduleBlocksTable.blockLabel,
      blockType: scheduleBlocksTable.blockType,
      notes: scheduleBlocksTable.notes,
      isRecurring: scheduleBlocksTable.isRecurring,
      recurrenceType: scheduleBlocksTable.recurrenceType,
      effectiveFrom: scheduleBlocksTable.effectiveFrom,
      effectiveTo: scheduleBlocksTable.effectiveTo,
      weekOf: scheduleBlocksTable.weekOf,
      isAutoGenerated: scheduleBlocksTable.isAutoGenerated,
      rotationDay: scheduleBlocksTable.rotationDay,
      createdAt: scheduleBlocksTable.createdAt,
      staffFirst: staffTable.firstName,
      staffLast: staffTable.lastName,
      studentFirst: studentsTable.firstName,
      studentLast: studentsTable.lastName,
      serviceTypeName: serviceTypesTable.name,
    })
    .from(scheduleBlocksTable)
    .leftJoin(staffTable, eq(staffTable.id, scheduleBlocksTable.staffId))
    .leftJoin(studentsTable, eq(studentsTable.id, scheduleBlocksTable.studentId))
    .leftJoin(serviceTypesTable, eq(serviceTypesTable.id, scheduleBlocksTable.serviceTypeId))
    .where(and(
      eq(scheduleBlocksTable.staffId, staffId),
      isNull(scheduleBlocksTable.deletedAt),
    ));

  res.json(blocks.map(b => blockToJson(
    b,
    b.staffFirst ? `${b.staffFirst} ${b.staffLast}` : null,
    b.studentFirst ? `${b.studentFirst} ${b.studentLast}` : null,
    b.serviceTypeName,
  )));
});

/**
 * GET /schedules/today
 * Returns the caller's schedule blocks for the current day of the week,
 * annotated with a `status` field: "logged" | "in_progress" | "missed" | "upcoming".
 * Also includes the matched session log id when status === "logged".
 */
router.get("/schedules/today", requireAuth, async (req, res): Promise<void> => {
  const authed = req as AuthedRequest;
  const staffId = resolveCallerStaffId(authed);

  if (!staffId) {
    res.status(403).json({ error: "No staff record linked to your account. Contact your administrator." });
    return;
  }

  const { pool } = await import("@workspace/db");

  const now = new Date();
  const DAY_NAMES = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  const todayDayName = DAY_NAMES[now.getDay()];
  const y = now.getFullYear();
  const mo = String(now.getMonth() + 1).padStart(2, "0");
  const dy = String(now.getDate()).padStart(2, "0");
  const todayStr = `${y}-${mo}-${dy}`;
  const nowMinutes = now.getHours() * 60 + now.getMinutes();

  const blocksResult = await pool.query<{
    id: number; staff_id: number; student_id: number | null; service_type_id: number | null;
    start_time: string; end_time: string; location: string | null; block_label: string | null;
    block_type: string | null; notes: string | null;
    is_recurring: boolean; recurrence_type: string; effective_from: string | null;
    student_first: string | null; student_last: string | null; service_type_name: string | null;
  }>(`
    SELECT
      sb.id, sb.staff_id, sb.student_id, sb.service_type_id,
      sb.start_time, sb.end_time, sb.location, sb.block_label, sb.block_type, sb.notes,
      sb.is_recurring, sb.recurrence_type, sb.effective_from,
      stu.first_name AS student_first, stu.last_name AS student_last,
      st.name AS service_type_name
    FROM schedule_blocks sb
    LEFT JOIN students stu ON stu.id = sb.student_id
    LEFT JOIN service_types st ON st.id = sb.service_type_id
    WHERE sb.staff_id = $1
      AND sb.day_of_week = $2
      AND sb.deleted_at IS NULL
      AND (sb.effective_from IS NULL OR sb.effective_from <= $3)
      AND (sb.effective_to IS NULL OR sb.effective_to >= $3)
    ORDER BY sb.start_time
  `, [staffId, todayDayName, todayStr]);

  const targetDate = new Date(todayStr + "T12:00:00");
  const activeBlockRows = blocksResult.rows.filter(b =>
    isBlockActiveOnDate(
      { id: b.id, isRecurring: b.is_recurring, recurrenceType: b.recurrence_type, effectiveFrom: b.effective_from },
      targetDate,
    )
  );

  const logsResult = await pool.query<{
    id: number; student_id: number | null; service_type_id: number | null; start_time: string | null; status: string;
  }>(`
    SELECT id, student_id, service_type_id, start_time, status
    FROM session_logs
    WHERE staff_id = $1 AND session_date = $2 AND deleted_at IS NULL
  `, [staffId, todayStr]);

  const logs = logsResult.rows;

  const blocks = activeBlockRows.map(b => {
    const [sh = 0, sm = 0] = (b.start_time ?? "00:00").split(":").map(Number);
    const [eh = 0, em = 0] = (b.end_time ?? "00:00").split(":").map(Number);
    const startMin = sh * 60 + sm;
    const endMin = eh * 60 + em;
    const durationMinutes = Math.max(0, endMin - startMin);

    let matched: { id: number; status: string } | null = null;

    // Step 1: student + service type + time-window overlap
    matched = logs.find(l => {
      if (l.student_id !== b.student_id) return false;
      if (b.service_type_id != null && l.service_type_id != null && l.service_type_id !== b.service_type_id) return false;
      if (!l.start_time) return false;
      const [lh = 0, lm = 0] = l.start_time.split(":").map(Number);
      const lMin = lh * 60 + lm;
      return lMin >= startMin - 30 && lMin <= endMin + 30;
    }) ?? null;

    // Step 2: student + service type, no time constraint
    if (!matched) {
      matched = logs.find(l =>
        l.student_id === b.student_id &&
        (b.service_type_id == null || l.service_type_id == null || l.service_type_id === b.service_type_id)
      ) ?? null;
    }

    let status: "logged" | "in_progress" | "missed" | "upcoming";
    if (matched) status = "logged";
    else if (nowMinutes >= startMin && nowMinutes < endMin) status = "in_progress";
    else if (endMin < nowMinutes) status = "missed";
    else status = "upcoming";

    return {
      id: b.id,
      staffId: b.staff_id,
      studentId: b.student_id,
      studentName: b.student_first ? `${b.student_first} ${b.student_last}` : null,
      serviceTypeId: b.service_type_id,
      serviceTypeName: b.service_type_name,
      startTime: b.start_time,
      endTime: b.end_time,
      durationMinutes,
      location: b.location,
      blockLabel: b.block_label,
      sessionLogId: matched?.id ?? null,
      status,
      date: todayStr,
    };
  });

  res.json(blocks);
});

router.post("/schedules/change-requests", requireAuth, async (req, res): Promise<void> => {
  const authed = req as unknown as AuthedRequest;
  const staffId = resolveCallerStaffId(authed);

  if (!staffId) {
    res.status(403).json({ error: "No staff record linked to your account. Contact your administrator." });
    return;
  }

  const parsed = CreateChangeRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (parsed.data.scheduleBlockId) {
    const [block] = await db
      .select({ staffId: scheduleBlocksTable.staffId })
      .from(scheduleBlocksTable)
      .where(and(
        eq(scheduleBlocksTable.id, parsed.data.scheduleBlockId),
        isNull(scheduleBlocksTable.deletedAt),
      ));

    if (!block) {
      res.status(404).json({ error: "Schedule block not found" });
      return;
    }
    if (block.staffId !== staffId) {
      res.status(403).json({ error: "You can only request changes for your own schedule blocks" });
      return;
    }
  }

  const [created] = await db.insert(scheduleChangeRequestsTable).values({
    staffId,
    scheduleBlockId: parsed.data.scheduleBlockId ?? null,
    requestType: parsed.data.requestType,
    notes: parsed.data.notes ?? null,
    requestedDate: parsed.data.requestedDate ?? null,
    requestedStartTime: parsed.data.requestedStartTime ?? null,
    requestedEndTime: parsed.data.requestedEndTime ?? null,
    status: "pending",
  }).returning();

  res.status(201).json(changeRequestRecordToJson(created as ChangeRequestRecord));
});

router.get("/schedules/change-requests", requireAuth, async (req, res): Promise<void> => {
  const authed = req as unknown as AuthedRequest;
  const isReviewer = ["admin", "coordinator", "case_manager"].includes(authed.trellisRole);
  const staffId = resolveCallerStaffId(authed);
  const { pool } = await import("@workspace/db");
  const districtId = authed.tenantDistrictId;

  if (isReviewer) {
    const whereClauses: string[] = [];
    const params: (string | number)[] = [];

    if (districtId) {
      params.push(districtId);
      whereClauses.push(`scr.staff_id IN (SELECT id FROM staff WHERE school_id IN (SELECT id FROM schools WHERE district_id = $${params.length}))`);
    }

    if (req.query.status && typeof req.query.status === "string") {
      params.push(req.query.status);
      whereClauses.push(`scr.status = $${params.length}`);
    }

    const where = whereClauses.length > 0 ? `WHERE ${whereClauses.join(" AND ")}` : "";

    const result = await pool.query<ChangeRequestRow>(
      `${CHANGE_REQUEST_SELECT_SQL} ${where} ORDER BY scr.created_at DESC LIMIT 200`,
      params,
    );
    res.json(result.rows.map(rowToJson));
    return;
  }

  if (!staffId) {
    res.status(403).json({ error: "No staff record linked to your account." });
    return;
  }

  const result = await pool.query<ChangeRequestRow>(
    `${CHANGE_REQUEST_SELECT_SQL} WHERE scr.staff_id = $1 ORDER BY scr.created_at DESC LIMIT 100`,
    [staffId],
  );
  res.json(result.rows.map(rowToJson));
});

router.patch("/schedules/change-requests/:id", requireReviewer, async (req, res): Promise<void> => {
  const authed = req as unknown as AuthedRequest;
  const id = Number(req.params.id);
  if (!id || isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const parsed = ReviewChangeRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  // Verify the change request belongs to the caller's district (cross-tenant protection).
  const districtId = authed.tenantDistrictId;
  if (districtId !== null) {
    const [ownership] = await db
      .select({ districtId: schoolsTable.districtId })
      .from(scheduleChangeRequestsTable)
      .innerJoin(staffTable, eq(staffTable.id, scheduleChangeRequestsTable.staffId))
      .innerJoin(schoolsTable, eq(schoolsTable.id, staffTable.schoolId))
      .where(eq(scheduleChangeRequestsTable.id, id));

    if (!ownership) {
      res.status(404).json({ error: "Change request not found" });
      return;
    }
    if (ownership.districtId !== districtId) {
      res.status(403).json({ error: "You do not have permission to review this request" });
      return;
    }
  }

  const reviewerStaffId = resolveCallerStaffId(authed);

  const [updated] = await db
    .update(scheduleChangeRequestsTable)
    .set({
      status: parsed.data.status,
      adminNotes: parsed.data.adminNotes ?? null,
      reviewedByStaffId: reviewerStaffId ?? null,
      reviewedAt: new Date(),
    })
    .where(eq(scheduleChangeRequestsTable.id, id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Change request not found" });
    return;
  }

  // Notify the requesting provider of the decision. Failures are logged but
  // never block the API response — the review is already persisted.
  void notifyProviderOfDecision(
    (updated as ChangeRequestRecord).id,
    (updated as ChangeRequestRecord).staffId,
    (updated as ChangeRequestRecord).requestType,
    parsed.data.status,
    parsed.data.adminNotes ?? null,
  ).catch(err => {
    console.error("[ChangeRequestEmail] Failed to dispatch decision email:", err);
  });

  res.json(changeRequestRecordToJson(updated as ChangeRequestRecord));
});

const REQUEST_TYPE_LABELS: Record<string, string> = {
  swap_time: "Swap Time",
  coverage_request: "Coverage Request",
  other: "Other",
};

async function notifyProviderOfDecision(
  requestId: number,
  requesterStaffId: number,
  requestType: string,
  decision: "approved" | "denied",
  adminNotes: string | null,
): Promise<void> {
  const [requester] = await db
    .select({
      email: staffTable.email,
      firstName: staffTable.firstName,
    })
    .from(staffTable)
    .where(eq(staffTable.id, requesterStaffId));

  if (!requester || !requester.email) {
    console.log(`[ChangeRequestEmail] Skipping notification for request ${requestId} — requester ${requesterStaffId} has no email on file.`);
    return;
  }

  const esc = (s: string): string => s
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

  const typeLabel = REQUEST_TYPE_LABELS[requestType] ?? requestType.replace(/_/g, " ");
  const decisionLabel = decision === "approved" ? "Approved" : "Denied";
  const headerColor = decision === "approved" ? "#059669" : "#b91c1c";
  const greetingName = requester.firstName ? requester.firstName : "there";
  const subject = `Your schedule change request was ${decision}`;

  const baseUrl = getAppBaseUrl();
  const linkHtml = baseUrl
    ? `<p style="margin-top:20px"><a href="${baseUrl}/my-schedule" style="background:#065f46;color:#fff;text-decoration:none;padding:10px 20px;border-radius:6px;font-weight:600;font-size:14px">View My Schedule →</a></p>`
    : "";
  const linkText = baseUrl ? `\n\nView your schedule: ${baseUrl}/my-schedule` : "";

  const adminNotesHtml = adminNotes && adminNotes.trim().length > 0
    ? `<p><strong>Reviewer note:</strong></p><blockquote style="margin:8px 0;padding:8px 12px;border-left:3px solid #e5e7eb;color:#374151;white-space:pre-wrap">${esc(adminNotes)}</blockquote>`
    : `<p style="color:#6b7280">No additional notes from the reviewer.</p>`;
  const adminNotesText = adminNotes && adminNotes.trim().length > 0
    ? `\n\nReviewer note:\n${adminNotes}`
    : "";

  const html = `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>${esc(subject)}</title></head>
<body style="font-family:Arial,sans-serif;font-size:14px;color:#111;background:#f9fafb;margin:0;padding:0">
<div style="max-width:600px;margin:24px auto;background:#fff;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden">
<div style="background:${headerColor};color:#fff;padding:18px 24px"><h1 style="margin:0;font-size:17px">Schedule Change Request ${esc(decisionLabel)}</h1></div>
<div style="padding:24px">
<p>Hi ${esc(greetingName)},</p>
<p>Your <strong>${esc(typeLabel)}</strong> request has been <strong>${esc(decisionLabel.toLowerCase())}</strong> by your reviewer.</p>
<ul style="color:#374151">
<li><strong>Request type:</strong> ${esc(typeLabel)}</li>
<li><strong>Decision:</strong> ${esc(decisionLabel)}</li>
</ul>
${adminNotesHtml}
${linkHtml}
</div>
<div style="background:#f3f4f6;padding:12px 24px;font-size:11px;color:#6b7280;border-top:1px solid #e5e7eb">Sent by Trellis SPED Compliance Platform.</div>
</div></body></html>`;

  const text = `Hi ${greetingName},\n\nYour ${typeLabel} request has been ${decisionLabel.toLowerCase()} by your reviewer.\n\nRequest type: ${typeLabel}\nDecision: ${decisionLabel}${adminNotesText}${linkText}\n\n— Trellis SPED Compliance Platform`;

  const result = await sendAdminEmail({
    to: [requester.email],
    subject,
    html,
    text,
    notificationType: "schedule_change_request_decision",
  });

  if (!result.success) {
    if (result.notConfigured) {
      console.log(`[ChangeRequestEmail] RESEND_API_KEY not configured — skipped notifying ${requester.email} for request ${requestId}.`);
    } else {
      console.error(`[ChangeRequestEmail] Failed to send decision email for request ${requestId}:`, result.error);
    }
  }
}

function changeRequestRecordToJson(r: ChangeRequestRecord) {
  return {
    id: r.id,
    staffId: r.staffId,
    scheduleBlockId: r.scheduleBlockId,
    requestType: r.requestType,
    notes: r.notes,
    requestedDate: r.requestedDate,
    requestedStartTime: r.requestedStartTime,
    requestedEndTime: r.requestedEndTime,
    status: r.status,
    adminNotes: r.adminNotes,
    reviewedByStaffId: r.reviewedByStaffId,
    reviewedAt: r.reviewedAt ? r.reviewedAt.toISOString() : null,
    createdAt: r.createdAt instanceof Date ? r.createdAt.toISOString() : String(r.createdAt),
  };
}

function rowToJson(r: ChangeRequestRow) {
  return {
    id: r.id,
    staffId: r.staff_id,
    staffName: r.staff_first ? `${r.staff_first} ${r.staff_last}` : null,
    staffRole: r.staff_role,
    scheduleBlockId: r.schedule_block_id,
    requestType: r.request_type,
    notes: r.notes,
    requestedDate: r.requested_date,
    requestedStartTime: r.requested_start_time,
    requestedEndTime: r.requested_end_time,
    status: r.status,
    adminNotes: r.admin_notes,
    reviewedByStaffId: r.reviewed_by_staff_id,
    reviewerName: r.reviewer_first ? `${r.reviewer_first} ${r.reviewer_last}` : null,
    reviewedAt: r.reviewed_at ? new Date(r.reviewed_at).toISOString() : null,
    createdAt: r.created_at ? new Date(r.created_at).toISOString() : null,
    blockDayOfWeek: r.day_of_week,
    blockStartTime: r.start_time,
    blockEndTime: r.end_time,
    blockLocation: r.location,
    studentName: r.student_first ? `${r.student_first} ${r.student_last}` : null,
    serviceTypeName: r.service_type_name,
  };
}

export default router;
