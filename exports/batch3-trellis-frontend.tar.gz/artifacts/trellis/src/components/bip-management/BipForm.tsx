import { X } from "lucide-react";
import { BipFormState, FUNCTION_OPTIONS } from "./types";
import {
  AntecedentStrategiesEditor,
  TeachingStrategiesEditor,
  ConsequenceProceduresEditor,
  ReinforcementEditor,
  CrisisSupportsEditor,
} from "./StrategyEditors";
import { FbaInsightsCompact } from "@/pages/behavior-assessment/FbaInsightsCard";
import type { FbaRecord, ObsSummary } from "@/pages/behavior-assessment/types";

function FormField({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-1">{label}</label>
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
      />
    </div>
  );
}

function FormTextarea({ label, value, onChange, rows = 2 }: { label: string; value: string; onChange: (v: string) => void; rows?: number }) {
  return (
    <div>
      <label className="block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-1">{label}</label>
      <textarea
        value={value}
        onChange={e => onChange(e.target.value)}
        rows={rows}
        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600 resize-y"
      />
    </div>
  );
}

export function BipForm({
  form,
  setForm,
  editing,
  saving,
  onSave,
  onCancel,
  fbas,
  behaviorTargets,
  fbaInsights,
}: {
  form: BipFormState;
  setForm: (f: BipFormState) => void;
  editing: boolean;
  saving: boolean;
  onSave: () => void;
  onCancel: () => void;
  fbas: any[];
  behaviorTargets: any[];
  /** Optional FBA context shown as a collapsible reference panel */
  fbaInsights?: { fba: FbaRecord; summary: ObsSummary | null } | null;
}) {
  const update = (key: keyof BipFormState, value: any) => setForm({ ...form, [key]: value });

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-gray-100 sticky top-0 bg-white rounded-t-xl z-10">
          <h2 className="text-base font-semibold text-gray-800">{editing ? "Edit BIP" : "New Behavior Intervention Plan"}</h2>
          <button onClick={onCancel} className="p-1.5 hover:bg-gray-100 rounded-lg">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* FBA Reference Panel — collapsible, shown when FBA context is available */}
          {fbaInsights && (
            <FbaInsightsCompact
              fba={fbaInsights.fba}
              summary={fbaInsights.summary}
              onApplyFunction={fn => update("hypothesizedFunction", fn)}
              onApplyTargetBehavior={tb => update("targetBehavior", tb)}
              onApplyOpDef={od => update("operationalDefinition", od)}
            />
          )}

          {/* Basic identification */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Target Behavior *" value={form.targetBehavior} onChange={v => update("targetBehavior", v)} />
            <div>
              <label className="block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-1">Hypothesized Function *</label>
              <select
                value={form.hypothesizedFunction}
                onChange={e => update("hypothesizedFunction", e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
              >
                {FUNCTION_OPTIONS.map(f => <option key={f} value={f}>{f.charAt(0).toUpperCase() + f.slice(1)}</option>)}
              </select>
            </div>
          </div>

          <FormTextarea label="Operational Definition *" value={form.operationalDefinition} onChange={v => update("operationalDefinition", v)} rows={3} />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {behaviorTargets.length > 0 && (
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-1">Linked Behavior Target</label>
                <select
                  value={form.behaviorTargetId}
                  onChange={e => update("behaviorTargetId", e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                >
                  <option value="">None</option>
                  {behaviorTargets.map((t: any) => <option key={t.id} value={t.id}>{t.name}</option>)}
                </select>
              </div>
            )}
            {fbas.length > 0 && (
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-1">Linked FBA</label>
                <select
                  value={form.fbaId}
                  onChange={e => update("fbaId", e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                >
                  <option value="">None</option>
                  {fbas.map((f: any) => <option key={f.id} value={f.id}>{f.targetBehavior} ({f.status})</option>)}
                </select>
              </div>
            )}
          </div>

          {/* ── Intervention Strategies (structured editors) ─────── */}
          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1">Intervention Strategies</h3>
            <p className="text-[10px] text-gray-400 mb-3">
              Use "Structured entry" to capture each strategy as a typed record with clinical vocabulary.
              Switch back to plain text at any time — both layers are preserved.
            </p>
            <div className="space-y-4">
              <AntecedentStrategiesEditor
                items={form.antecedentStrategiesStructured}
                legacyText={form.preventionStrategies}
                onItemsChange={v => update("antecedentStrategiesStructured", v)}
                onLegacyChange={v => update("preventionStrategies", v)}
              />
              <TeachingStrategiesEditor
                items={form.teachingStrategiesStructured}
                legacyText={form.teachingStrategies}
                onItemsChange={v => update("teachingStrategiesStructured", v)}
                onLegacyChange={v => update("teachingStrategies", v)}
              />
              {/* Replacement behaviors stays as plain text — it's a goal statement, not a strategy list */}
              <FormTextarea label="Replacement Behaviors (goal statement)" value={form.replacementBehaviors} onChange={v => update("replacementBehaviors", v)} rows={2} />
              <ConsequenceProceduresEditor
                items={form.consequenceProceduresStructured}
                legacyText={form.consequenceStrategies}
                onItemsChange={v => update("consequenceProceduresStructured", v)}
                onLegacyChange={v => update("consequenceStrategies", v)}
              />
            </div>
          </div>

          {/* ── Reinforcement & Crisis (structured editors) ────── */}
          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Reinforcement & Crisis</h3>
            <div className="space-y-4">
              <ReinforcementEditor
                items={form.reinforcementComponentsStructured}
                legacyText={form.reinforcementSchedule}
                onItemsChange={v => update("reinforcementComponentsStructured", v)}
                onLegacyChange={v => update("reinforcementSchedule", v)}
              />
              <CrisisSupportsEditor
                items={form.crisisSupportsStructured}
                legacyText={form.crisisPlan}
                onItemsChange={v => update("crisisSupportsStructured", v)}
                onLegacyChange={v => update("crisisPlan", v)}
              />
            </div>
          </div>

          {/* ── Data & Progress ─────────────────────────────────── */}
          <div className="border-t border-gray-100 pt-4">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Data & Progress</h3>
            <div className="space-y-3">
              <FormTextarea label="Data Collection Method" value={form.dataCollectionMethod} onChange={v => update("dataCollectionMethod", v)} rows={2} />
              <FormTextarea label="Progress Criteria" value={form.progressCriteria} onChange={v => update("progressCriteria", v)} rows={2} />
              <FormTextarea label="Implementation Notes" value={form.implementationNotes} onChange={v => update("implementationNotes", v)} rows={2} />
            </div>
          </div>

          {/* ── Lifecycle ────────────────────────────────────────── */}
          <div className="border-t border-gray-100 pt-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-[11px] font-semibold uppercase tracking-wider text-gray-500 mb-1">Status</label>
                <select
                  value={form.status}
                  onChange={e => update("status", e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600/20 focus:border-emerald-600"
                >
                  <option value="draft">Draft</option>
                  <option value="active">Active</option>
                  <option value="under_review">Under Review</option>
                </select>
              </div>
              <FormField label="Effective Date" value={form.effectiveDate} onChange={v => update("effectiveDate", v)} type="date" />
              <FormField label="Review Date" value={form.reviewDate} onChange={v => update("reviewDate", v)} type="date" />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-100 sticky bottom-0 bg-white rounded-b-xl">
          <button onClick={onCancel} className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
            Cancel
          </button>
          <button
            onClick={onSave}
            disabled={saving}
            className="px-4 py-2 text-sm bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-600/90 disabled:opacity-50 transition-colors"
          >
            {saving ? "Saving..." : editing ? "Update BIP" : "Create BIP"}
          </button>
        </div>
      </div>
    </div>
  );
}
