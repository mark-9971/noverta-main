import { Fragment, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { authFetch } from "@/lib/auth-fetch";
import { useSchoolYears } from "@/lib/use-school-years";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Download, AlertTriangle, ExternalLink } from "lucide-react";
import { Link } from "wouter";
import { toast } from "sonner";

type Scope = "interval" | "schoolYear";

interface ExposureItem {
  date: string;
  serviceType: string;
  provider: string;
  scheduledDurationMinutes: number;
  status: string;
  hourlyRate: number | null;
  rateSource: string;
  exposureAmount: number | null;
  serviceRequirementId: number;
}

interface ExposureDetail {
  studentId: number;
  studentName: string;
  items: ExposureItem[];
  aggregateExposure: number;
  aggregateShortfallMinutes: number;
  rateConfigured: boolean;
  scope?: Scope;
  window?: { startDate: string; endDate: string } | null;
}

function fmtDollars(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(n);
}

function fmtDate(dateStr: string) {
  const [y, m, d] = dateStr.split("-");
  return new Date(Number(y), Number(m) - 1, Number(d)).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric",
  });
}

function statusLabel(status: string) {
  if (status === "missed") return "Missed";
  if (status === "partial") return "Partial";
  return status.charAt(0).toUpperCase() + status.slice(1);
}

function monthKey(dateStr: string) {
  const [y, m] = dateStr.split("-");
  return `${y}-${m}`;
}

function fmtMonth(key: string) {
  const [y, m] = key.split("-");
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString("en-US", {
    month: "long",
    year: "numeric",
  });
}

function groupByMonth(items: ExposureItem[]): { key: string; items: ExposureItem[]; subtotal: number }[] {
  const groups = new Map<string, ExposureItem[]>();
  for (const item of items) {
    const key = monthKey(item.date);
    const arr = groups.get(key);
    if (arr) arr.push(item);
    else groups.set(key, [item]);
  }
  return Array.from(groups.entries())
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([key, groupItems]) => ({
      key,
      items: groupItems,
      subtotal: Math.round(groupItems.reduce((acc, it) => acc + (it.exposureAmount ?? 0), 0) * 100) / 100,
    }));
}

function statusBadge(status: string) {
  const cls = status === "missed"
    ? "bg-red-100 text-red-700 border-red-200"
    : "bg-amber-100 text-amber-700 border-amber-200";
  return (
    <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold border ${cls}`}>
      {statusLabel(status)}
    </span>
  );
}

function downloadCSV(
  data: ExposureDetail,
  itemsExposureTotal: number,
  scope: Scope,
  schoolYearLabel: string | null,
) {
  const isYear = scope === "schoolYear";
  const scopeLabel = isYear
    ? `Full School Year${schoolYearLabel ? ` (${schoolYearLabel})` : ""}`
    : "Current Service Interval";

  const metaRows: string[][] = [
    ["Student", data.studentName],
    ["Scope", scopeLabel],
  ];
  if (data.window) {
    metaRows.push(["Window", `${data.window.startDate} to ${data.window.endDate}`]);
  }
  metaRows.push([]);

  const headers = ["Date", "Service Type", "Provider", "Scheduled Duration (min)", "Status", "CPT Rate", "Exposure Amount"];
  const rows = data.items.map(item => [
    item.date,
    item.serviceType,
    item.provider,
    String(item.scheduledDurationMinutes),
    statusLabel(item.status),
    item.hourlyRate != null ? `$${item.hourlyRate.toFixed(2)}/hr` : "Rate not configured",
    item.exposureAmount != null ? `$${item.exposureAmount.toFixed(2)}` : "N/A",
  ]);

  // The reconciliation row only makes sense for the current interval, where
  // the aggregate shortfall comes from required-vs-delivered minutes that may
  // not be backed by explicit session logs. In school-year mode the aggregate
  // is the sum of logged sessions, so there is no remainder to surface.
  if (!isYear) {
    const remainingExposure = Math.round((data.aggregateExposure - itemsExposureTotal) * 100) / 100;
    if (remainingExposure > 0.005) {
      rows.push([
        "",
        "Remaining shortfall (minutes without logged sessions)",
        "",
        "",
        "",
        "",
        `$${remainingExposure.toFixed(2)}`,
      ]);
    }
  }

  rows.push([
    "TOTAL",
    "",
    "",
    "",
    "",
    "",
    `$${data.aggregateExposure.toFixed(2)}`,
  ]);

  const escape = (v: string) => {
    if (v.includes(",") || v.includes('"') || v.includes("\n")) {
      return `"${v.replace(/"/g, '""')}"`;
    }
    return v;
  };

  const csv = [...metaRows, headers, ...rows].map(row => row.map(escape).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const safeName = data.studentName.replace(/\s+/g, "_");
  const suffix = isYear && schoolYearLabel
    ? `SY${schoolYearLabel.replace(/\s+/g, "")}`
    : new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `Exposure_Detail_${safeName}_${suffix}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

interface Props {
  studentId: number | null;
  studentName?: string;
  serviceRequirementId?: number;
  onClose: () => void;
}

export default function ExposureDetailPanel({ studentId, studentName, serviceRequirementId, onClose }: Props) {
  const [scope, setScope] = useState<Scope>("interval");
  const { activeYear } = useSchoolYears();
  const yearId = scope === "schoolYear" ? activeYear?.id ?? null : null;

  const query = useQuery<ExposureDetail>({
    queryKey: ["/api/reports/exposure-detail", studentId, serviceRequirementId, yearId],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (serviceRequirementId != null) params.set("serviceRequirementId", String(serviceRequirementId));
      if (yearId != null) params.set("schoolYearId", String(yearId));
      const qs = params.toString();
      const res = await authFetch(`/api/reports/exposure-detail/${studentId}${qs ? `?${qs}` : ""}`);
      if (!res.ok) throw new Error("Failed to load exposure detail");
      return res.json();
    },
    enabled: studentId != null,
    staleTime: 30_000,
  });

  const data = query.data;

  // Sum of explicitly-logged session exposures (items that have a rate configured)
  const itemsExposureTotal = data
    ? Math.round(data.items.reduce((acc, it) => acc + (it.exposureAmount ?? 0), 0) * 100) / 100
    : 0;

  // Gap between aggregate shortfall exposure and sum of logged sessions.
  // A positive value means some shortfall minutes had no corresponding session log.
  const remainingExposure = data
    ? Math.round((data.aggregateExposure - itemsExposureTotal) * 100) / 100
    : 0;

  return (
    <Sheet open={studentId != null} onOpenChange={open => { if (!open) onClose(); }}>
      <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto p-0">
        <SheetHeader className="px-5 py-4 border-b bg-gray-50/70 sticky top-0 z-10">
          <div className="flex items-start justify-between gap-3">
            <div>
              <SheetTitle className="text-base font-bold text-gray-800">
                Financial Exposure — {studentName ?? data?.studentName ?? "Student"}
              </SheetTitle>
              <p className="text-[12px] text-gray-400 mt-0.5 font-normal">
                {scope === "schoolYear"
                  ? `Itemised missed & partial sessions across the ${activeYear?.label ?? "school year"}`
                  : "Itemised missed & partial sessions for the current service interval"}
              </p>
            </div>
            {studentId != null && (
              <Link
                href={`/students/${studentId}`}
                className="flex items-center gap-1 text-[12px] text-blue-600 hover:text-blue-800 hover:underline whitespace-nowrap mt-0.5 shrink-0 font-medium transition-colors"
              >
                View record <ExternalLink className="w-3 h-3" />
              </Link>
            )}
          </div>
        </SheetHeader>

        <div className="px-5 py-4 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div
              role="tablist"
              aria-label="Exposure window"
              className="inline-flex rounded-lg border border-gray-200 bg-gray-50 p-0.5 text-[12px] font-medium"
            >
              <button
                type="button"
                role="tab"
                aria-selected={scope === "interval"}
                onClick={() => setScope("interval")}
                className={`px-3 py-1.5 rounded-md transition-colors ${
                  scope === "interval"
                    ? "bg-white text-gray-800 shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                Current Interval
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={scope === "schoolYear"}
                onClick={() => setScope("schoolYear")}
                disabled={!activeYear}
                title={!activeYear ? "No active school year configured" : undefined}
                className={`px-3 py-1.5 rounded-md transition-colors ${
                  scope === "schoolYear"
                    ? "bg-white text-gray-800 shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                Full School Year
              </button>
            </div>
            {scope === "schoolYear" && data?.window && (
              <span className="text-[11px] text-gray-400 tabular-nums">
                {fmtDate(data.window.startDate)} – {fmtDate(data.window.endDate)}
              </span>
            )}
          </div>

          {query.isLoading && (
            <div className="flex items-center justify-center py-16">
              <div className="animate-spin h-7 w-7 border-2 border-emerald-600 border-t-transparent rounded-full" />
            </div>
          )}

          {query.isError && (
            <div className="flex items-center gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-4 py-3">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              Failed to load exposure details. Please try again.
            </div>
          )}

          {data && data.items.length === 0 && (
            <div className="py-12 text-center text-sm text-gray-500">
              <p className="font-medium text-gray-700 mb-1">No missed or partial sessions logged</p>
              <p className="text-[13px] text-gray-400">
                {scope === "schoolYear"
                  ? `No missed or partial sessions have been logged for this student during the ${activeYear?.label ?? "school year"}.`
                  : `This student has no explicitly logged missed or partial sessions in the current interval. The shortfall of ${data.aggregateShortfallMinutes} min reflects required minutes not yet delivered.`}
              </p>
            </div>
          )}

          {data && (
            <>
              <div className="overflow-x-auto rounded-lg border border-gray-200">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 text-[10px] font-semibold text-gray-400 uppercase tracking-wide border-b border-gray-200">
                      <th className="px-3 py-2.5 text-left">Date</th>
                      <th className="px-3 py-2.5 text-left">Service Type</th>
                      <th className="px-3 py-2.5 text-left">Provider</th>
                      <th className="px-3 py-2.5 text-right">Sched. (min)</th>
                      <th className="px-3 py-2.5 text-left">Status</th>
                      <th className="px-3 py-2.5 text-right">CPT Rate</th>
                      <th className="px-3 py-2.5 text-right">Exposure</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {scope === "schoolYear" ? (
                      groupByMonth(data.items).map(group => (
                        <Fragment key={group.key}>
                          <tr className="bg-gray-50/80">
                            <td
                              colSpan={7}
                              className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-gray-500"
                            >
                              {fmtMonth(group.key)}
                              <span className="ml-2 text-[10px] font-normal text-gray-400 normal-case tracking-normal">
                                ({group.items.length} {group.items.length === 1 ? "session" : "sessions"})
                              </span>
                            </td>
                          </tr>
                          {group.items.map((item, i) => (
                            <tr key={`${group.key}-${i}`} className="hover:bg-gray-50/60 transition-colors">
                              <td className="px-3 py-2.5 text-[12px] text-gray-600 whitespace-nowrap">{fmtDate(item.date)}</td>
                              <td className="px-3 py-2.5 text-[12px] text-gray-700 max-w-[140px] truncate">{item.serviceType}</td>
                              <td className="px-3 py-2.5 text-[12px] text-gray-600 max-w-[120px] truncate">{item.provider}</td>
                              <td className="px-3 py-2.5 text-[13px] text-gray-700 text-right tabular-nums font-medium">{item.scheduledDurationMinutes}</td>
                              <td className="px-3 py-2.5">{statusBadge(item.status)}</td>
                              <td className="px-3 py-2.5 text-right text-[12px] tabular-nums">
                                {item.hourlyRate != null
                                  ? <span className="text-gray-700">${item.hourlyRate.toFixed(2)}/hr</span>
                                  : <span className="text-amber-600 font-medium">Not set</span>}
                              </td>
                              <td className="px-3 py-2.5 text-right tabular-nums">
                                {item.exposureAmount != null
                                  ? <span className="text-red-700 font-semibold text-[13px]">{fmtDollars(item.exposureAmount)}</span>
                                  : <span className="text-amber-600 text-[12px]">N/A</span>}
                              </td>
                            </tr>
                          ))}
                          <tr className="bg-gray-50/60">
                            <td colSpan={6} className="px-3 py-1.5 text-[11px] font-medium text-gray-500 text-right italic">
                              {fmtMonth(group.key)} subtotal
                            </td>
                            <td className="px-3 py-1.5 text-right tabular-nums">
                              <span className="text-red-700 font-semibold text-[12px]">{fmtDollars(group.subtotal)}</span>
                            </td>
                          </tr>
                        </Fragment>
                      ))
                    ) : (
                      data.items.map((item, i) => (
                        <tr key={i} className="hover:bg-gray-50/60 transition-colors">
                          <td className="px-3 py-2.5 text-[12px] text-gray-600 whitespace-nowrap">{fmtDate(item.date)}</td>
                          <td className="px-3 py-2.5 text-[12px] text-gray-700 max-w-[140px] truncate">{item.serviceType}</td>
                          <td className="px-3 py-2.5 text-[12px] text-gray-600 max-w-[120px] truncate">{item.provider}</td>
                          <td className="px-3 py-2.5 text-[13px] text-gray-700 text-right tabular-nums font-medium">{item.scheduledDurationMinutes}</td>
                          <td className="px-3 py-2.5">{statusBadge(item.status)}</td>
                          <td className="px-3 py-2.5 text-right text-[12px] tabular-nums">
                            {item.hourlyRate != null
                              ? <span className="text-gray-700">${item.hourlyRate.toFixed(2)}/hr</span>
                              : <span className="text-amber-600 font-medium">Not set</span>}
                          </td>
                          <td className="px-3 py-2.5 text-right tabular-nums">
                            {item.exposureAmount != null
                              ? <span className="text-red-700 font-semibold text-[13px]">{fmtDollars(item.exposureAmount)}</span>
                              : <span className="text-amber-600 text-[12px]">N/A</span>}
                          </td>
                        </tr>
                      ))
                    )}

                    {remainingExposure > 0.005 && scope === "schoolYear" && (
                      <>
                        <tr className="bg-gray-50/80">
                          <td
                            colSpan={7}
                            className="px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wide text-gray-500"
                          >
                            Unlogged shortfall
                            <span className="ml-2 text-[10px] font-normal text-gray-400 normal-case tracking-normal">
                              (shortfall minutes without logged sessions)
                            </span>
                          </td>
                        </tr>
                        <tr className="bg-gray-50/60">
                          <td colSpan={6} className="px-3 py-1.5 text-[11px] font-medium text-gray-500 text-right italic">
                            Unlogged shortfall subtotal
                          </td>
                          <td className="px-3 py-1.5 text-right tabular-nums">
                            <span className="text-red-700 font-semibold text-[12px]">{fmtDollars(remainingExposure)}</span>
                          </td>
                        </tr>
                      </>
                    )}
                    {remainingExposure > 0.005 && scope !== "schoolYear" && (
                      <tr className="bg-amber-50/40 hover:bg-amber-50/60 transition-colors">
                        <td className="px-3 py-2.5 text-[12px] text-gray-400 whitespace-nowrap italic">—</td>
                        <td colSpan={5} className="px-3 py-2.5 text-[12px] text-gray-500 italic">
                          Remaining shortfall (minutes without logged sessions)
                        </td>
                        <td className="px-3 py-2.5 text-right tabular-nums">
                          <span className="text-red-600 font-semibold text-[13px]">{fmtDollars(remainingExposure)}</span>
                        </td>
                      </tr>
                    )}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-gray-200 bg-gray-50">
                      <td colSpan={5} className="px-3 py-2.5 text-[12px] font-semibold text-gray-600">
                        Total Exposure
                        <span className="ml-2 text-[11px] font-normal text-gray-400">
                          ({data.aggregateShortfallMinutes} min shortfall × rate ÷ 60)
                        </span>
                      </td>
                      <td />
                      <td className="px-3 py-2.5 text-right tabular-nums">
                        {data.rateConfigured
                          ? <span className="text-red-700 font-bold text-[14px]">{fmtDollars(data.aggregateExposure)}</span>
                          : <span className="text-amber-600 font-semibold text-[13px]">Rate not configured</span>}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              <p className="text-[11px] text-gray-400 leading-relaxed">
                Based on service-type CPT rates. Adjust rates in{" "}
                <a
                  href="/settings?tab=cpt-codes"
                  className="text-emerald-600 hover:underline"
                >
                  Settings → CPT Codes
                </a>
                . Total reflects the aggregate shortfall (required − delivered minutes × rate ÷ 60) used by the Compliance Risk Report.
                The reconciliation row accounts for shortfall minutes not captured via explicit session logs.
              </p>
            </>
          )}

          {data && !data.rateConfigured && (
            <div className="flex items-start gap-2 text-[12px] text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-600" />
              <span>
                One or more service types do not have a configured CPT rate. Configure rates in{" "}
                <a href="/settings?tab=cpt-codes" className="underline font-medium">
                  Settings → CPT Codes
                </a>{" "}
                to see dollar exposure amounts.
              </span>
            </div>
          )}

          {data && (
            <div className="flex justify-end pt-2">
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5 text-xs"
                onClick={() => {
                  try {
                    downloadCSV(
                      data,
                      itemsExposureTotal,
                      scope,
                      scope === "schoolYear" ? activeYear?.label ?? null : null,
                    );
                  } catch {
                    toast.error("Failed to export CSV");
                  }
                }}
              >
                <Download className="w-3.5 h-3.5" />
                Export as CSV
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
