import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { useUser } from "@clerk/react";
import { useLocation } from "wouter";
import { setExtraHeaders } from "@workspace/api-client-react";
import { setAuthFetchExtraHeaders, getDevAuthBypassHeaders } from "@/lib/auth-fetch";

export type UserRole =
  | "admin"
  | "case_manager"
  | "bcba"
  | "sped_teacher"
  | "coordinator"
  | "provider"
  | "para"
  | "direct_provider"
  | "sped_student"
  | "sped_parent"
  | "trellis_support";

export const STAFF_ROLES: UserRole[] = [
  "admin", "case_manager", "bcba", "sped_teacher", "coordinator", "provider", "para", "direct_provider",
];

export const ROLE_SUBTITLES: Record<UserRole, string> = {
  admin: "Administrator",
  case_manager: "Case Manager",
  bcba: "BCBA",
  sped_teacher: "SPED Teacher",
  coordinator: "Coordinator",
  provider: "Provider",
  para: "Paraprofessional",
  direct_provider: "Direct Provider",
  sped_student: "Student",
  sped_parent: "Parent / Guardian",
  trellis_support: "Trellis Support (read-only)",
};

// Phase 2C-3: bcba and sped_teacher land on /today (matches their
// nav-config.ts homeHref and their sidebar's primary "Today" entry),
// not the admin /Dashboard surface.
const ROLE_HOME: Record<UserRole, string> = {
  admin: "/",
  case_manager: "/",
  bcba: "/today",
  sped_teacher: "/today",
  coordinator: "/",
  provider: "/my-day",
  para: "/my-day",
  direct_provider: "/my-day",
  sped_student: "/sped-portal",
  sped_parent: "/guardian-portal",
  trellis_support: "/support-session",
};

const VALID_ROLES = new Set<string>([
  "admin", "case_manager", "bcba", "sped_teacher", "coordinator", "provider", "para", "direct_provider",
  "sped_student", "sped_parent", "trellis_support",
]);

function isValidRole(r: unknown): r is UserRole {
  return typeof r === "string" && VALID_ROLES.has(r);
}

function lsGet(key: string, fallback = ""): string {
  try { return localStorage.getItem(key) || fallback; } catch { return fallback; }
}
function lsSet(key: string, value: string) {
  try { localStorage.setItem(key, value); } catch {}
}
function lsDel(key: string) {
  try { localStorage.removeItem(key); } catch {}
}

interface RoleUser {
  name: string;
  subtitle: string;
  initials: string;
}

interface RoleContextType {
  role: UserRole;
  user: RoleUser;
  isDevMode: boolean;
  isPlatformAdmin: boolean;
  studentId: number;
  teacherId: number;
  guardianId: number;
  setRole: (role: UserRole) => void;
  setStudentId: (id: number, name?: string) => void;
  setTeacherId: (id: number, name?: string) => void;
  setGuardianId: (id: number) => void;
}

const RoleContext = createContext<RoleContextType | null>(null);

function getInitials(name: string): string {
  return name.split(" ").map(n => n[0]).filter(Boolean).join("").slice(0, 2).toUpperCase();
}

export function RoleProvider({ children }: { children: ReactNode }) {
  const { user: clerkUser, isLoaded } = useUser();
  const [, setLocation] = useLocation();
  const isDevMode = import.meta.env.DEV;

  const [devRole, setDevRoleState] = useState<UserRole | null>(() => {
    if (!import.meta.env.DEV) return null;
    const saved = lsGet("trellis_role");
    return isValidRole(saved) ? saved : null;
  });

  const [devStudentId, setDevStudentIdState] = useState<number>(() => {
    return Number(lsGet("trellis_sped_student_id")) || 0;
  });

  const [devStudentName, setDevStudentName] = useState<string>(() => {
    return lsGet("trellis_sped_student_name");
  });

  const [devTeacherId, setDevTeacherIdState] = useState<number>(() => {
    return Number(lsGet("trellis_teacher_id")) || 0;
  });

  const [devGuardianId, setDevGuardianIdState] = useState<number>(() => {
    return Number(lsGet("trellis_guardian_id")) || 1;
  });

  const clerkRole = isValidRole(clerkUser?.publicMetadata?.role)
    ? (clerkUser!.publicMetadata!.role as UserRole)
    : null;

  const clerkStudentId = Number(clerkUser?.publicMetadata?.studentId) || 0;
  const clerkStaffId = Number(clerkUser?.publicMetadata?.staffId) || 0;
  const isPlatformAdmin = clerkUser?.publicMetadata?.platformAdmin === true;

  const role: UserRole = (isDevMode && devRole) ? devRole : (clerkRole ?? (isDevMode ? "admin" : "sped_teacher"));
  const studentId = (isDevMode && devStudentId) ? devStudentId : clerkStudentId;
  const teacherId = (isDevMode && devTeacherId) ? devTeacherId : clerkStaffId;
  const clerkGuardianId = Number(clerkUser?.publicMetadata?.guardianId) || 0;
  const guardianId = (isDevMode && devGuardianId) ? devGuardianId : clerkGuardianId;

  useEffect(() => {
    if (isDevMode) {
      const headers: Record<string, string> = { "x-demo-role": role };
      if (role === "sped_parent") {
        headers["x-demo-guardian-id"] = String(guardianId);
      }
      // Preserve dev auth bypass headers so RoleProvider doesn't clobber them.
      Object.assign(headers, getDevAuthBypassHeaders());
      setExtraHeaders(headers);
      setAuthFetchExtraHeaders(headers);
    }
    return () => {
      if (isDevMode) {
        setExtraHeaders(null);
        setAuthFetchExtraHeaders(null);
      }
    };
  }, [isDevMode, role, guardianId]);

  const clerkName = clerkUser?.fullName || clerkUser?.firstName || "";
  const userName = (isDevMode && devRole)
    ? (role === "sped_student" && devStudentName ? devStudentName : `Demo ${ROLE_SUBTITLES[role]}`)
    : (clerkName || "User");

  const user: RoleUser = {
    name: userName,
    subtitle: ROLE_SUBTITLES[role] || role,
    initials: getInitials(userName) || "T",
  };

  function setRole(r: UserRole) {
    if (!isDevMode) return;
    setDevRoleState(r);
    lsSet("trellis_role", r);
    setLocation(ROLE_HOME[r]);
  }

  function setStudentId(id: number, name?: string) {
    if (!isDevMode) return;
    setDevStudentIdState(id);
    lsSet("trellis_sped_student_id", String(id));
    if (name) {
      setDevStudentName(name);
      lsSet("trellis_sped_student_name", name);
    }
  }

  function setTeacherId(id: number, _name?: string) {
    if (!isDevMode) return;
    setDevTeacherIdState(id);
    lsSet("trellis_teacher_id", String(id));
  }

  function setGuardianId(id: number) {
    if (!isDevMode) return;
    setDevGuardianIdState(id);
    lsSet("trellis_guardian_id", String(id));
  }

  if (!isLoaded) return null;

  return (
    <RoleContext.Provider value={{
      role,
      user,
      isDevMode,
      isPlatformAdmin,
      studentId,
      teacherId,
      guardianId,
      setRole,
      setStudentId,
      setTeacherId,
      setGuardianId,
    }}>
      {children}
    </RoleContext.Provider>
  );
}

export function useRole() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRole must be used within RoleProvider");
  return ctx;
}
