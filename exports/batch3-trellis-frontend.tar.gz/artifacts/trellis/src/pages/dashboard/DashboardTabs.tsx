import {
  AlertTriangle, Shield, Clipboard, ArrowRight, FileBarChart, DollarSign,
  BarChart2, Briefcase, CalendarClock, AlertCircle, Target,
} from "lucide-react";
import { Link } from "wouter";
import { Users, Clock, Bell, CheckCircle } from "lucide-react";
import type { RiskOverview, AlertsSummary, ComplianceByService, Alert } from "@workspace/api-client-react";
import type { DashboardSummaryExtended, ProviderCaseloadSummary } from "./types";
import { MetricCard } from "./MetricCard";
import { ComplianceRingCard, SessionTrendCard, ComplianceByServiceCard, RecentAlertsCard } from "./ChartsSection";
import { GoalMasteryBreakdownCard } from "@/components/dashboard/GoalMasteryBreakdownCard";
import type { ServiceAreaMastery } from "@/components/dashboard/GoalMasteryBreakdownCard";
import {
  AccommodationComplianceCard, EvaluationTimelineRiskCard, TransitionsSection,
  MeetingsSection, ContractRenewalsCard, DeadlinesSection, IepExpirationCard,
  TrendDelta,
} from "./SecondarySections";
import CostRiskPanel from "@/components/dashboard/CostRiskPanel";
import SystemStatusBanner from "@/components/dashboard/SystemStatusBanner";
import MakeupSessionsCard from "@/components/dashboard/MakeupSessionsCard";
import ParentEngagementCard from "./ParentEngagementCard";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DistrictComparisonCard } from "./DistrictComparisonCard";

/** Lightly-typed shape for data fetched from non-OpenAPI endpoints */
interface TransitionDashboard {
  missingPlan: number;
  incompletePlans: number;
  approachingTransitionAge: number;
  overdueFollowups: number;
}

interface MeetingDashboard {
  overdueCount: number;
  thisWeekCount: number;
  pendingConsentCount: number;
}

interface AccommodationComplianceData {
  totalStudents: number;
  overallComplianceRate: number;
  students: { overdueCount: number }[];
}

interface TrendPoint {
  weekLabel?: string;
  completedCount?: number;
  missedCount?: number;
}

interface RiskPiePoint {
  name: string;
  value: number;
}

interface DeadlineItem {
  studentName: string;
  eventType: string;
  daysUntilDue?: number;
  daysRemaining?: number;
}

interface EvalTimelineRiskStudent {
  referralId: number;
  studentId: number | null;
  studentName: string;
  consentDate: string;
  daysElapsed: number;
  daysRemaining: number;
  isOverdue: boolean;
}

interface EvalTimelineRisk {
  students: EvalTimelineRiskStudent[];
  deadlineDays: number;
}

/**
 * Prior-week snapshot from /api/reports/compliance-week-trend.
 * `available: false` is the graceful-fallback signal — when the snapshot
 * job hasn't run yet (fresh install) or there are no active students, the
 * KPI cards simply hide their delta indicators.
 */
export interface WeekTrendSnapshot {
  available: boolean;
  studentsOutOfCompliance?: number;
  studentsAtRisk?: number;
  studentsOnTrack?: number;
  overallComplianceRate?: number;
  /**
   * Prior-week on-track-student percentage matching the dashboard's hero
   * Compliance Rate card definition (studentsOnTrack / tracked, where tracked
   * is the same three-bucket sum exposed here). Null when no students were
   * tracked at all in the prior-week window.
   */
  onTrackStudentRate?: number | null;
  secondary?: {
    goalMastery?: { masteryRate: number | null };
  };
}

export interface DashboardTabsProps {
  isAdmin: boolean;
  myCaseload: ProviderCaseloadSummary | null;
  hasTrackedData: boolean;
  onTrackPct: number;
  complianceSubtitle: string;
  s: DashboardSummaryExtended | null;
  ro: RiskOverview | null;
  alerts: AlertsSummary | null;
  recent: Alert[];
  riskPieData: RiskPiePoint[];
  trendData: TrendPoint[];
  serviceData: ComplianceByService[];
  transitionDash: TransitionDashboard | null;
  meetingDash: MeetingDashboard | null;
  accommodationCompliance: AccommodationComplianceData | null;
  deadlines: DeadlineItem[];
  goalMasteryRate: number | null;
  goalMasterySubtitle?: string;
  goalMasteryBreakdown?: ServiceAreaMastery[];
  evalTimelineRisk: EvalTimelineRisk | null;
  weekTrend?: WeekTrendSnapshot | null;
  /** Current value displayed on the High-Risk Students card (out + at-risk). */
  currentHighRiskCount?: number;
  /** Current value displayed on the Goal Mastery Rate card (percent, or null). */
  currentGoalMasteryRate?: number | null;
  /**
   * Current on-track-student percentage computed with the same denominator
   * as `WeekTrendSnapshot.onTrackStudentRate` (excludes slightly_behind), so
   * the WoW delta on the Compliance Rate card is apples-to-apples. Null when
   * no students fall into the three comparable buckets.
   */
  currentOnTrackComparable?: number | null;
}

export function DashboardTabs({
  isAdmin, myCaseload, hasTrackedData, onTrackPct, complianceSubtitle,
  s, ro, alerts, recent, riskPieData, trendData, serviceData,
  transitionDash, meetingDash, accommodationCompliance, deadlines,
  goalMasteryRate, goalMasterySubtitle, goalMasteryBreakdown,
  evalTimelineRisk, weekTrend, currentHighRiskCount, currentGoalMasteryRate,
  currentOnTrackComparable,
}: DashboardTabsProps) {
  const quickActions = [
    { label: "Compliance Risk Report", icon: AlertTriangle, href: "/compliance-risk-report", color: "text-red-700 bg-red-50 hover:bg-red-100" },
    { label: "Required vs Delivered", icon: Shield, href: "/compliance", color: "text-emerald-700 bg-emerald-50 hover:bg-emerald-100" },
    { label: "High-Risk Students", icon: Users, href: "/compliance-risk-report#needs-attention", color: "text-amber-700 bg-amber-50 hover:bg-amber-100" },
    { label: "Weekly Summary", icon: FileBarChart, href: "/weekly-compliance-summary", color: "text-blue-700 bg-blue-50 hover:bg-blue-100" },
    { label: "Compensatory Exposure", icon: DollarSign, href: "/compensatory?view=finance", color: "text-rose-700 bg-rose-50 hover:bg-rose-100" },
    { label: "Log Session", icon: Clipboard, href: "/sessions", color: "text-gray-700 bg-gray-50 hover:bg-gray-100" },
  ];

  // ── Week-over-week deltas for the KPI cards.
  // Each delta is null unless the prior-week snapshot returned data AND we
  // have a current value to compare against. The TrendDelta component hides
  // itself on null, so cards without prior data render cleanly (graceful
  // fallback). Caseload variants of the cards intentionally have no deltas —
  // the prior-week endpoint is district-scoped, not per-staff.
  const trendAvailable = weekTrend?.available === true && !myCaseload;

  const priorHighRiskCount = trendAvailable
    && weekTrend!.studentsOutOfCompliance !== undefined
    && weekTrend!.studentsAtRisk !== undefined
    ? weekTrend!.studentsOutOfCompliance + weekTrend!.studentsAtRisk
    : null;
  const highRiskDelta = priorHighRiskCount !== null && currentHighRiskCount !== undefined
    ? currentHighRiskCount - priorHighRiskCount
    : null;

  const priorGoalMastery = trendAvailable
    ? weekTrend!.secondary?.goalMastery?.masteryRate ?? null
    : null;
  const goalMasteryDelta = priorGoalMastery !== null && currentGoalMasteryRate !== null && currentGoalMasteryRate !== undefined
    ? currentGoalMasteryRate - priorGoalMastery
    : null;

  // Compliance Rate WoW delta. Both sides use the same three-bucket
  // denominator (on_track + at_risk + out_of_compliance), excluding
  // slightly_behind which the snapshot does not store. The displayed
  // percentage on the card still uses the broader trackedStudents
  // denominator — only the arrow is computed from comparable values.
  const priorComplianceRate = trendAvailable
    && weekTrend!.onTrackStudentRate !== undefined
    && weekTrend!.onTrackStudentRate !== null
    ? weekTrend!.onTrackStudentRate
    : null;
  const complianceRateDelta = priorComplianceRate !== null
    && currentOnTrackComparable !== null
    && currentOnTrackComparable !== undefined
    ? currentOnTrackComparable - priorComplianceRate
    : null;

  // Operational counters from dashboard summary
  const uncoveredToday = s?.uncoveredBlocksToday ?? 0;
  const conflictsToday = s?.scheduleConflictsToday ?? 0;
  const makeupObligations = s?.openMakeupObligations ?? 0;
  const missedThisWeek = s?.missedSessionsThisWeek ?? 0;
  const shortfallMinutes = s?.totalShortfallMinutes ?? 0;
  const outOfComplianceStudents = s?.outOfComplianceStudents ?? 0;

  return (
    <Tabs defaultValue="overview" className="w-full">
      {/* Tab bar — horizontally scrollable on mobile */}
      <div className="overflow-x-auto -mx-1 px-1">
        <TabsList className="inline-flex w-auto min-w-full sm:min-w-0 gap-1 bg-gray-100/80 p-1 rounded-xl mb-1">
          <TabsTrigger
            value="overview"
            className="flex items-center gap-1.5 text-[13px] px-4 py-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-gray-900 text-gray-500 rounded-lg whitespace-nowrap"
          >
            <BarChart2 className="w-3.5 h-3.5" />
            Overview
          </TabsTrigger>
          <TabsTrigger
            value="compliance"
            className="flex items-center gap-1.5 text-[13px] px-4 py-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-gray-900 text-gray-500 rounded-lg whitespace-nowrap"
          >
            <Shield className="w-3.5 h-3.5" />
            Compliance &amp; Risk
          </TabsTrigger>
          <TabsTrigger
            value="operations"
            className="flex items-center gap-1.5 text-[13px] px-4 py-1.5 data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-gray-900 text-gray-500 rounded-lg whitespace-nowrap"
          >
            <Briefcase className="w-3.5 h-3.5" />
            Operations
          </TabsTrigger>
        </TabsList>
      </div>

      {/* ── Overview tab ─────────────────────────────────────────────────
          Contains: wedge banner, 4 metric cards, quick actions,
          today's plan vs. actual sessions count, compliance ring,
          session trend chart.
      ─────────────────────────────────────────────────────────────────── */}
      <TabsContent value="overview" className="space-y-6 md:space-y-8 mt-4">
        {/* Wedge banner — pulls admins to the compliance risk report */}
        {isAdmin && (
          <Link href="/compliance-risk-report">
            <div
              className="rounded-2xl border border-emerald-200 bg-gradient-to-r from-emerald-50 via-white to-white p-4 md:p-5 hover:shadow-sm transition-shadow cursor-pointer flex items-center gap-4 group"
              data-testid="banner-risk-report"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center flex-shrink-0">
                <AlertTriangle className="w-5 h-5 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm md:text-[15px] font-semibold text-gray-900">Open the Compliance Risk Report</div>
                <div className="text-xs md:text-sm text-gray-500 mt-0.5">
                  Required vs delivered minutes, high-risk students, compensatory exposure, and the next best actions — in one place.
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-emerald-700 group-hover:translate-x-0.5 transition-transform flex-shrink-0" />
            </div>
          </Link>
        )}

        {/* 5 top-line metric cards */}
        {(() => {
          const providerHasNoStudents = !!myCaseload && (myCaseload.assignedStudents ?? 0) === 0;
          const providerEmptyMsg = "No students assigned yet — contact your administrator";
          return (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 md:gap-4">
          <MetricCard
            title={myCaseload ? "Your Caseload" : "Compliance Rate"}
            value={myCaseload
              ? (providerHasNoStudents ? "—" : myCaseload.assignedStudents)
              : (hasTrackedData ? `${onTrackPct}%` : "—")}
            icon={myCaseload ? Users : Shield}
            accent={myCaseload
              ? (providerHasNoStudents ? "amber" : "emerald")
              : (!hasTrackedData ? "amber" : (onTrackPct >= 95 ? "emerald" : onTrackPct >= 85 ? "amber" : "red"))}
            subtitle={myCaseload ? "students assigned" : complianceSubtitle}
            emptyState={providerHasNoStudents ? providerEmptyMsg : undefined}
            href={myCaseload ? "/students" : "/compliance?tab=minutes"}
            delta={!myCaseload && complianceRateDelta !== null
              ? <TrendDelta delta={complianceRateDelta} positiveIsGood={true} suffix="% vs. last wk" />
              : null}
          />
          <MetricCard
            title={myCaseload ? "Sessions Delivered" : "High-Risk Students"}
            value={myCaseload
              ? (providerHasNoStudents ? "—" : `${myCaseload.totalDeliveredMinutes} min`)
              : (outOfComplianceStudents + (ro?.atRisk ?? 0))}
            icon={myCaseload ? Clock : AlertTriangle}
            accent={myCaseload
              ? (providerHasNoStudents ? "amber" : "emerald")
              : ((outOfComplianceStudents + (ro?.atRisk ?? 0)) > 0 ? "red" : "emerald")}
            subtitle={myCaseload
              ? `of ${myCaseload.totalRequiredMinutes} required`
              : `${outOfComplianceStudents} out of compliance · ${ro?.atRisk ?? 0} at risk`}
            emptyState={providerHasNoStudents ? providerEmptyMsg : undefined}
            href={myCaseload ? "/sessions" : "/compliance?tab=risk-report"}
            delta={!myCaseload && highRiskDelta !== null
              ? <TrendDelta delta={highRiskDelta} positiveIsGood={false} suffix=" vs. last wk" />
              : null}
          />
          <MetricCard
            title={myCaseload ? "Compliance" : "Urgent Actions"}
            value={myCaseload
              ? (providerHasNoStudents ? "—" : `${myCaseload.utilizationPercent}%`)
              : ((alerts?.critical ?? 0) + makeupObligations)}
            icon={myCaseload ? CheckCircle : Bell}
            accent={myCaseload
              ? (providerHasNoStudents ? "amber" : (myCaseload.utilizationPercent >= 80 ? "emerald" : "amber"))
              : ((alerts?.critical ?? 0) + makeupObligations > 0 ? "red" : "emerald")}
            subtitle={myCaseload
              ? "of your students on track"
              : `${alerts?.critical ?? 0} critical alert${(alerts?.critical ?? 0) !== 1 ? "s" : ""} · ${makeupObligations} makeup${makeupObligations !== 1 ? "s" : ""} due`}
            emptyState={providerHasNoStudents ? providerEmptyMsg : undefined}
            href={myCaseload ? "/compliance?tab=minutes" : "/action-center"}
          />
          <MetricCard
            title={myCaseload ? "At Risk" : "Compensatory Exposure"}
            value={myCaseload
              ? (providerHasNoStudents ? "—" : myCaseload.studentsAtRisk)
              : (shortfallMinutes > 0 ? `${shortfallMinutes.toLocaleString()} min` : "0 min")}
            icon={myCaseload ? AlertTriangle : DollarSign}
            accent={myCaseload
              ? (providerHasNoStudents ? "amber" : (myCaseload.studentsAtRisk > 0 ? "red" : "emerald"))
              : (shortfallMinutes > 0 ? "red" : "emerald")}
            subtitle={myCaseload ? "students in your caseload" : "total service-minute shortfall this period"}
            emptyState={providerHasNoStudents ? providerEmptyMsg : undefined}
            href={myCaseload ? "/compliance?tab=minutes" : "/compliance?tab=risk-report"}
          />
          <MetricCard
            title="Goal Mastery Rate"
            value={goalMasteryRate !== null ? `${goalMasteryRate}%` : "—"}
            icon={Target}
            accent={goalMasteryRate === null ? "emerald" : (goalMasteryRate >= 75 ? "emerald" : goalMasteryRate >= 55 ? "amber" : "red")}
            subtitle={goalMasterySubtitle ?? "of rated goals on track or mastered"}
            emptyState={providerHasNoStudents ? providerEmptyMsg : undefined}
            href="/progress-reports"
            delta={goalMasteryDelta !== null
              ? <TrendDelta delta={goalMasteryDelta} positiveIsGood={true} suffix="% vs. last wk" />
              : null}
          />
        </div>
          );
        })()}

        {/* Goal mastery by service area — compact breakdown beneath the top-line card.
            On small screens, the summary toggle is visible so it can be collapsed.
            On sm+ the summary is hidden (sm:hidden) and details stays open — always visible. */}
        {goalMasteryBreakdown && goalMasteryBreakdown.length > 0 && (
          <details className="group" open>
            <summary className="list-none cursor-pointer sm:hidden flex items-center gap-1.5 text-xs font-medium text-gray-500 mb-2 select-none">
              <Target className="w-3.5 h-3.5 text-gray-400" />
              <span>Goal mastery by service area</span>
              <span className="ml-auto text-[10px] text-gray-400 group-open:hidden">Show</span>
              <span className="ml-auto text-[10px] text-gray-400 hidden group-open:inline">Hide</span>
            </summary>
            <GoalMasteryBreakdownCard breakdown={goalMasteryBreakdown} />
          </details>
        )}

        {/* District comparison — platform-admin only, self-hides when <2 districts */}
        <DistrictComparisonCard />

        {/* Quick actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {quickActions.map(action => (
            <Link key={action.href} href={action.href}>
              <div className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-[12px] font-medium cursor-pointer transition-colors ${action.color}`}>
                <action.icon className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="truncate">{action.label}</span>
              </div>
            </Link>
          ))}
        </div>

        {/* Today's plan vs. actual sessions count */}
        {s && (uncoveredToday > 0 || missedThisWeek > 0 || conflictsToday > 0) && (
          <Card className="border-gray-200/60">
            <CardContent className="py-3 px-5">
              <div className="flex items-center gap-3 flex-wrap text-[12px]">
                <div className="flex items-center gap-2 flex-shrink-0">
                  <CalendarClock className="w-4 h-4 text-gray-400" />
                  <span className="text-sm font-semibold text-gray-700">Today's Session Status</span>
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                  {uncoveredToday > 0 && (
                    <Link href="/coverage">
                      <span className="px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 font-medium cursor-pointer hover:opacity-80 transition-opacity">
                        <span className="font-bold">{uncoveredToday}</span> uncovered block{uncoveredToday !== 1 ? "s" : ""}
                      </span>
                    </Link>
                  )}
                  {conflictsToday > 0 && (
                    <span className="px-2.5 py-1 rounded-full bg-red-50 text-red-700 font-medium">
                      <span className="font-bold">{conflictsToday}</span> conflict{conflictsToday !== 1 ? "s" : ""}
                    </span>
                  )}
                  {missedThisWeek > 0 && (
                    <Link href="/sessions?filter=missed">
                      <span className="px-2.5 py-1 rounded-full bg-gray-50 text-gray-600 font-medium cursor-pointer hover:opacity-80 transition-opacity">
                        <span className="font-bold">{missedThisWeek}</span> missed this week
                      </span>
                    </Link>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {isAdmin && s && (
          <SystemStatusBanner errorsLast24h={s.errorsLast24h ?? 0} />
        )}

        {/* Charts: compliance ring + session trend */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <ComplianceRingCard ro={ro} riskPieData={riskPieData} onTrackPct={onTrackPct} />
          <SessionTrendCard trendData={trendData} />
        </div>
      </TabsContent>

      {/* ── Compliance & Risk tab ─────────────────────────────────────────
          Contains: cost/risk panel (admin), compliance by service,
          recent alerts, overdue makeup sessions tracker, accommodation
          compliance, evaluations & transitions, IEP meetings.
      ─────────────────────────────────────────────────────────────────── */}
      <TabsContent value="compliance" className="space-y-6 md:space-y-8 mt-4">
        {/* Cost & Risk Exposure panel — preserves original admin-only gating */}
        {isAdmin && <CostRiskPanel />}

        {/* Compliance by service + Recent alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ComplianceByServiceCard serviceData={serviceData} />
          <RecentAlertsCard recent={recent} />
        </div>

        {/* Overdue makeup sessions tracker */}
        <MakeupSessionsCard />

        {/* Accommodation compliance */}
        {accommodationCompliance && (
          <AccommodationComplianceCard accommodationCompliance={accommodationCompliance} />
        )}

        {/* IEP expiration countdown — renewals due within 90 days */}
        <IepExpirationCard />

        {/* Evaluation Timeline Risk — 60-day IDEA consent clock */}
        <EvaluationTimelineRiskCard
          students={evalTimelineRisk?.students ?? []}
          deadlineDays={evalTimelineRisk?.deadlineDays ?? 60}
        />

        {/* Transition Planning */}
        <TransitionsSection transitionDash={transitionDash} />

        {/* IEP Meetings — includes missing-document / pending-consent tracking */}
        <MeetingsSection meetingDash={meetingDash} />
      </TabsContent>

      {/* ── Operations tab ────────────────────────────────────────────────
          Contains: uncovered sessions count, schedule conflicts,
          contract renewals, IEP deadlines timeline.
          Future widgets (staff absence, provider leaderboard, credential
          alerts, parent portal engagement, pilot health) are downstream tasks.
      ─────────────────────────────────────────────────────────────────── */}
      <TabsContent value="operations" className="space-y-6 md:space-y-8 mt-4">
        {/* Coverage & scheduling — uncovered sessions count */}
        {s && (
          <Card className="border-gray-200/60">
            <CardHeader className="pb-0">
              <CardTitle className="text-sm font-semibold text-gray-600 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-gray-400" />
                Coverage &amp; Scheduling Snapshot
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 pb-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                <Link href="/coverage">
                  <div className={`p-3 rounded-lg border cursor-pointer hover:shadow-sm transition-shadow ${uncoveredToday > 0 ? "bg-amber-50 border-amber-200" : "bg-gray-50 border-gray-200"}`}>
                    <div className={`text-2xl font-bold ${uncoveredToday > 0 ? "text-amber-700" : "text-gray-600"}`}>{uncoveredToday}</div>
                    <div className="text-[11px] text-gray-500 mt-0.5">Uncovered sessions today</div>
                  </div>
                </Link>
                <div className={`p-3 rounded-lg border ${conflictsToday > 0 ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-200"}`}>
                  <div className={`text-2xl font-bold ${conflictsToday > 0 ? "text-red-700" : "text-gray-600"}`}>{conflictsToday}</div>
                  <div className="text-[11px] text-gray-500 mt-0.5">Schedule conflicts today</div>
                </div>
                <div className="p-3 rounded-lg border bg-gray-50 border-gray-200">
                  <div className="text-2xl font-bold text-gray-600">{missedThisWeek}</div>
                  <div className="text-[11px] text-gray-500 mt-0.5">Sessions missed this week</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Parent portal engagement */}
        {isAdmin && <ParentEngagementCard />}

        {/* Contract renewals */}
        {isAdmin && s?.contractRenewals && s.contractRenewals.length > 0 && (
          <ContractRenewalsCard contractRenewals={s.contractRenewals} />
        )}

        {/* IEP deadlines timeline */}
        <DeadlinesSection deadlines={deadlines} />
      </TabsContent>
    </Tabs>
  );
}
