import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { authFetch } from "@/lib/auth-fetch";
import { buildDocumentHtml, openPrintWindow, esc, fmtDate } from "@/lib/print-document";
import { FileText, Calendar, MessageSquare, User, ShieldCheck, Inbox, Download, Loader2, Info } from "lucide-react";
import { Link } from "wouter";
import RoleFirstRunCard from "@/components/onboarding/RoleFirstRunCard";

interface GuardianMe {
  guardian: { id: number; name: string; relationship: string; email: string | null };
  student: { id: number; firstName: string; lastName: string; grade: string | null } | null;
}

interface ParentSummaryReport {
  student: { id: number; firstName: string; lastName: string; grade: string | null; schoolName: string | null };
  providers: Array<{ role: string | null }>;
  reportingPeriod: { label: string | null; start: string | null; end: string | null } | null;
  overallSummary: string | null;
  parentNotes: string | null;
  goalSummaries: Array<{ area: string; goalNumber?: number | null; statusLabel: string; parentFriendlyNarrative?: string | null }>;
  servicesSummary: Array<{ serviceType: string | null; parentFriendly: string }>;
}

function buildParentReportHtml(report: ParentSummaryReport): string {
  const { student, providers, reportingPeriod, overallSummary, parentNotes, goalSummaries, servicesSummary } = report;
  const studentName = `${student.firstName} ${student.lastName}`;

  const periodLabel = reportingPeriod?.label
    ? `${reportingPeriod.label}${reportingPeriod.start ? ` (${fmtDate(reportingPeriod.start)} – ${fmtDate(reportingPeriod.end)})` : ""}`
    : null;

  const goalsHtml = goalSummaries.length === 0
    ? `<p style="color:#6b7280;font-size:12px">No goal data available for this reporting period.</p>`
    : goalSummaries.map(g => {
        const label = g.statusLabel || "In Progress";
        const badgeColor = label === "Mastered" || label === "On Track" ? "badge-green"
          : label === "Making Progress" ? "badge-green"
          : label === "Needs Support" ? "badge-amber"
          : label === "Needs Attention" ? "badge-red"
          : "badge-gray";
        return `<div class="field-box">
  <div class="field-label">${esc(g.area)}${g.goalNumber != null ? ` — Goal #${g.goalNumber}` : ""} &nbsp;<span class="badge ${badgeColor}">${esc(label)}</span></div>
  ${g.parentFriendlyNarrative ? `<p style="margin:4px 0 0;line-height:1.5">${esc(g.parentFriendlyNarrative)}</p>` : ""}
</div>`;
      }).join("\n");

  const servicesHtml = servicesSummary.length === 0
    ? `<p style="color:#6b7280;font-size:12px">No service data available for this reporting period.</p>`
    : `<table>
  <thead><tr><th>Service</th><th>Summary</th></tr></thead>
  <tbody>
    ${servicesSummary.map(s => `<tr>
      <td style="white-space:nowrap">${esc(s.serviceType ?? "Service")}</td>
      <td>${esc(s.parentFriendly)}</td>
    </tr>`).join("")}
  </tbody>
</table>`;

  const teamHtml = providers.length === 0
    ? `<p style="color:#6b7280;font-size:12px">No team members listed.</p>`
    : `<table>
  <thead><tr><th>Role</th></tr></thead>
  <tbody>
    ${providers.map(p => `<tr><td>${esc(p.role ?? "Provider")}</td></tr>`).join("")}
  </tbody>
</table>`;

  const sections = [
    ...(periodLabel ? [{
      heading: "Reporting Period",
      html: `<div class="field-box">${esc(periodLabel)}</div>`,
    }] : []),
    ...(overallSummary ? [{
      heading: "How Your Child Is Doing",
      html: `<div class="field-box" style="line-height:1.6">${esc(overallSummary)}</div>`,
    }] : []),
    {
      heading: "Goal Progress",
      html: goalsHtml,
    },
    {
      heading: "Services This Period",
      html: servicesHtml,
    },
    {
      heading: "Your Child's Team",
      html: teamHtml,
    },
    ...(parentNotes ? [{
      heading: "Notes for Families",
      html: `<div class="field-box" style="line-height:1.6">${esc(parentNotes)}</div>`,
    }] : []),
  ];

  return buildDocumentHtml({
    documentTitle: "Progress Report",
    documentSubtitle: "Parent/Guardian Summary — Prepared by Your Child's Education Team",
    studentName,
    studentGrade: student.grade ?? undefined,
    school: student.schoolName ?? undefined,
    sections,
    footerHtml: `<p style="margin:2px 0">This summary is prepared for families. For detailed academic data, please contact your child's case manager.</p>`,
  });
}

export default function GuardianPortalHome() {
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const { data, isLoading, error } = useQuery<GuardianMe>({
    queryKey: ["guardian-portal-me"],
    queryFn: ({ signal }) =>
      authFetch("/api/guardian-portal/me", { signal }).then(r => {
        if (!r.ok) throw new Error("Failed to load profile");
        return r.json();
      }),
  });

  const { data: docsData } = useQuery<{ documents: Array<{ id: number; acknowledgedAt: string | null }> }>({
    queryKey: ["guardian-portal-documents"],
    queryFn: ({ signal }) =>
      authFetch("/api/guardian-portal/documents", { signal }).then(r => r.json()),
    enabled: !!data,
  });

  const { data: msgData } = useQuery<{ threads: any[]; unreadTotal: number }>({
    queryKey: ["guardian-portal-messages"],
    queryFn: ({ signal }) =>
      authFetch("/api/guardian-portal/messages", { signal }).then(r => r.ok ? r.json() : { threads: [], unreadTotal: 0 }),
    enabled: !!data,
  });

  const { data: reportData, isError: reportFetchError, refetch: refetchReport } = useQuery<ParentSummaryReport | null>({
    queryKey: ["parent-summary-report", data?.student?.id],
    queryFn: async ({ signal }) => {
      const res = await authFetch(`/api/reports/parent-summary/${data!.student!.id}?parentSafe=true`, { signal });
      if (!res.ok) {
        const body: { error?: string } = await res.json().catch(() => ({}));
        throw new Error(body.error ?? `Request failed (${res.status})`);
      }
      return res.json();
    },
    enabled: !!data?.student?.id,
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });

  const hasReport = reportData !== undefined && reportData !== null && reportData.reportingPeriod !== null;

  async function handleDownloadReport() {
    if (!data?.student?.id) return;
    setIsDownloading(true);
    setDownloadError(null);
    try {
      const report: ParentSummaryReport = reportData ?? await (async () => {
        const res = await authFetch(`/api/reports/parent-summary/${data.student!.id}?parentSafe=true`);
        if (!res.ok) {
          const body: { error?: string } = await res.json().catch(() => ({}));
          throw new Error(body.error ?? `Request failed (${res.status})`);
        }
        return res.json();
      })();
      const html = buildParentReportHtml(report);
      openPrintWindow(html);
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : "Could not load the report. Please try again.";
      setDownloadError(msg);
    } finally {
      setIsDownloading(false);
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="w-8 h-8 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-2xl mx-auto mt-16 text-center">
        <ShieldCheck className="w-12 h-12 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-500 text-sm">Unable to load your portal. Please contact your school administrator.</p>
      </div>
    );
  }

  const { guardian, student } = data;
  const docs = docsData?.documents ?? [];
  const pendingAck = docs.filter(d => !d.acknowledgedAt).length;
  const unreadMessages = msgData?.unreadTotal ?? 0;
  const messageThreads = msgData?.threads?.length ?? 0;
  const studentName = student ? `${student.firstName} ${student.lastName}` : "your child";
  // First-run signal: nothing has been shared with this guardian yet —
  // no documents, no message threads. (Meetings query is deferred so we
  // don't gate on it.) When true we show the role-specific empty state
  // alongside the four feature tiles instead of a row of zeros.
  const isFirstRun = docs.length === 0 && messageThreads === 0;
  const guardianFirstName = guardian.name?.split(" ")[0];

  return (
    <div className="max-w-3xl mx-auto space-y-6 p-1">
      <div className="bg-white rounded-xl border border-gray-200/80 shadow-sm p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
            <User className="w-6 h-6 text-emerald-700" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gray-900">Welcome, {guardian.name}</h1>
            <p className="text-sm text-gray-500 mt-0.5">
              {guardian.relationship ? `${guardian.relationship} of ` : ""}{studentName}
              {student?.grade ? ` · Grade ${student.grade}` : ""}
            </p>
            <p className="text-xs text-gray-400 mt-1">Secure portal — view documents, messages, and respond to your school team</p>
          </div>
        </div>
      </div>

      {/* Honest first-run guidance for guardians whose case manager
          hasn't shared anything yet. Replaces a screen full of "0"
          counts with what to expect and what to do now. */}
      {isFirstRun && <RoleFirstRunCard role="guardian" personName={guardianFirstName} />}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Link href="/guardian-portal/messages">
          <a className="bg-white rounded-xl border border-gray-200/80 shadow-sm p-5 hover:border-emerald-300 hover:shadow-md transition-all cursor-pointer block group">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-lg bg-emerald-50 flex items-center justify-center">
                <Inbox className="w-5 h-5 text-emerald-600" />
              </div>
              <span className="font-semibold text-gray-800 text-sm group-hover:text-emerald-700 transition-colors">Messages</span>
            </div>
            <p className="text-xs text-gray-500">
              {unreadMessages > 0 ? (
                <span className="text-emerald-600 font-medium">{unreadMessages} unread</span>
              ) : (
                "View inbox"
              )}
            </p>
          </a>
        </Link>

        <Link href="/guardian-portal/documents">
          <a className="bg-white rounded-xl border border-gray-200/80 shadow-sm p-5 hover:border-emerald-300 hover:shadow-md transition-all cursor-pointer block group">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-lg bg-amber-50 flex items-center justify-center">
                <FileText className="w-5 h-5 text-amber-600" />
              </div>
              <span className="font-semibold text-gray-800 text-sm group-hover:text-emerald-700 transition-colors">Documents</span>
            </div>
            <p className="text-2xl font-bold text-gray-900">{docs.length}</p>
            <p className="text-xs text-gray-500 mt-1">
              {pendingAck > 0 ? (
                <span className="text-amber-600 font-medium">{pendingAck} pending acknowledgment</span>
              ) : (
                "All acknowledged"
              )}
            </p>
          </a>
        </Link>

        <Link href="/guardian-portal/meetings">
          <a className="bg-white rounded-xl border border-gray-200/80 shadow-sm p-5 hover:border-emerald-300 hover:shadow-md transition-all cursor-pointer block group">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-blue-600" />
              </div>
              <span className="font-semibold text-gray-800 text-sm group-hover:text-emerald-700 transition-colors">Meetings</span>
            </div>
            <p className="text-xs text-gray-500">View IEP meetings</p>
          </a>
        </Link>

        <Link href="/guardian-portal/contact-history">
          <a className="bg-white rounded-xl border border-gray-200/80 shadow-sm p-5 hover:border-emerald-300 hover:shadow-md transition-all cursor-pointer block group">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-lg bg-purple-50 flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-purple-600" />
              </div>
              <span className="font-semibold text-gray-800 text-sm group-hover:text-emerald-700 transition-colors">Contact History</span>
            </div>
            <p className="text-xs text-gray-500">View school communications</p>
          </a>
        </Link>
      </div>

      {student && (
        <div className="bg-white rounded-xl border border-gray-200/80 shadow-sm p-5">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-teal-50 flex items-center justify-center flex-shrink-0">
                <FileText className="w-5 h-5 text-teal-600" />
              </div>
              <div>
                <p className="font-semibold text-gray-800 text-sm">Progress Report</p>
                <p className="text-xs text-gray-500">Download a family-friendly summary of {student.firstName}'s goals and services</p>
              </div>
            </div>
            {reportFetchError ? null : reportData === undefined ? (
              <div className="w-8 h-8 flex items-center justify-center flex-shrink-0">
                <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
              </div>
            ) : hasReport ? (
              <button
                onClick={handleDownloadReport}
                disabled={isDownloading}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 disabled:cursor-not-allowed text-white text-sm font-medium transition-colors flex-shrink-0"
              >
                {isDownloading
                  ? <Loader2 className="w-4 h-4 animate-spin" />
                  : <Download className="w-4 h-4" />}
                {isDownloading ? "Loading…" : "Download Progress Report"}
              </button>
            ) : null}
          </div>
          {reportFetchError && (
            <div className="mt-3 flex items-center justify-between gap-3 rounded-lg bg-red-50 border border-red-200 px-3 py-2.5">
              <p className="text-xs text-red-700">Could not load report availability. Please try again.</p>
              <button
                onClick={() => refetchReport()}
                className="text-xs text-red-700 font-medium underline underline-offset-2 hover:text-red-900 flex-shrink-0"
              >
                Retry
              </button>
            </div>
          )}
          {!reportFetchError && reportData !== undefined && !hasReport && (
            <div className="mt-3 flex items-start gap-2 rounded-lg bg-blue-50 border border-blue-100 px-3 py-2.5">
              <Info className="w-4 h-4 text-blue-500 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-blue-700">No report available yet — check back after the first reporting period.</p>
            </div>
          )}
          {downloadError && (
            <p className="mt-3 text-xs text-red-600 bg-red-50 border border-red-200 rounded px-3 py-2">{downloadError}</p>
          )}
        </div>
      )}

      <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4">
        <p className="text-xs text-emerald-800">
          <span className="font-semibold">Your secure parent portal.</span>{" "}
          View documents, meetings, and messages from your child's education team.
          You can reply to messages and respond to conference requests directly through the portal.
        </p>
      </div>
    </div>
  );
}
