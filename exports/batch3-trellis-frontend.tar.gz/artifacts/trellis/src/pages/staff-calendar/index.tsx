import { useState, useEffect, useMemo } from "react";
import { useSearch } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useRole } from "@/lib/role-context";
import { authFetch } from "@/lib/auth-fetch";
import { Calendar, Plus, AlertTriangle, Download, FileText, Sheet } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { openPrintWindow, esc } from "@/lib/print-document";
import {
  StaffSchedule, Conflict, CoverageGap, ProviderSummary,
  StaffOption, SchoolOption, ServiceTypeOption, FormDataT,
  SCHOOL_COLORS, SCHOOL_COLOR_HEX, WEEKDAYS, WEEKDAY_LABELS, formatTime, timeToMinutes,
} from "./types";
import { FilterBar } from "./FilterBar";
import { ScheduleGrid } from "./ScheduleGrid";
import { ProviderSummaryPanel } from "./ProviderSummaryPanel";
import { CoverageGapsPanel } from "./CoverageGapsPanel";
import { ScheduleFormDialog } from "./ScheduleFormDialog";
import { ConflictsDialog } from "./ConflictsDialog";

interface StaffCalendarProps {
  embedded?: boolean;
}

export default function StaffCalendar({ embedded = false }: StaffCalendarProps) {
  const { role } = useRole();
  const isAdmin = role === "admin" || role === "coordinator";

  const search = useSearch();
  const searchParams = new URLSearchParams(search);
  const initialStaffId = searchParams.get("staffId") ?? "all";

  const [schedules, setSchedules] = useState<StaffSchedule[]>([]);
  const [conflicts, setConflicts] = useState<Conflict[]>([]);
  const [coverageGaps, setCoverageGaps] = useState<CoverageGap[]>([]);
  const [providerSummary, setProviderSummary] = useState<ProviderSummary | null>(null);
  const [staffList, setStaffList] = useState<StaffOption[]>([]);
  const [schoolList, setSchoolList] = useState<SchoolOption[]>([]);
  const [serviceTypeList, setServiceTypeList] = useState<ServiceTypeOption[]>([]);
  const [loading, setLoading] = useState(true);

  const [filterStaff, setFilterStaff] = useState<string>(initialStaffId);
  const [filterSchool, setFilterSchool] = useState<string>("all");
  const [filterServiceType, setFilterServiceType] = useState<string>("all");
  const [exportStartDate, setExportStartDate] = useState<string>("");
  const [exportEndDate, setExportEndDate] = useState<string>("");

  const [showForm, setShowForm] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState<StaffSchedule | null>(null);
  const [formData, setFormData] = useState<FormDataT>({
    staffId: "", schoolId: "", serviceTypeId: "", dayOfWeek: "monday", startTime: "08:00", endTime: "12:00", label: "", notes: "", effectiveFrom: "", effectiveTo: "",
  });
  const [saving, setSaving] = useState(false);
  const [showConflicts, setShowConflicts] = useState(false);

  useEffect(() => { loadData(); }, []);

  useEffect(() => {
    if (filterStaff !== "all") {
      authFetch(`/api/staff-schedules/provider-summary/${filterStaff}`)
        .then(r => r.ok ? r.json() : null)
        .then(d => setProviderSummary(d))
        .catch(() => setProviderSummary(null));
    } else {
      setProviderSummary(null);
    }
  }, [filterStaff]);

  async function loadData() {
    setLoading(true);
    try {
      const [schedRes, conflictRes, gapsRes, staffRes, schoolRes, stRes] = await Promise.all([
        authFetch("/api/staff-schedules").then(r => r.ok ? r.json() : { schedules: [] }),
        authFetch("/api/staff-schedules/conflicts").then(r => r.ok ? r.json() : { conflicts: [] }),
        authFetch("/api/staff-schedules/coverage-gaps").then(r => r.ok ? r.json() : { gaps: [] }),
        authFetch("/api/staff?limit=500").then(r => r.ok ? r.json() : { staff: [] }),
        authFetch("/api/schools").then(r => r.ok ? r.json() : []),
        authFetch("/api/service-types").then(r => r.ok ? r.json() : []),
      ]);
      setSchedules(schedRes.schedules || []);
      setConflicts(conflictRes.conflicts || []);
      setCoverageGaps(gapsRes.gaps || []);
      const stArr = Array.isArray(stRes) ? stRes : (stRes.serviceTypes || []);
      setServiceTypeList(stArr.map((s: Record<string, unknown>) => ({
        id: s.id as number, name: s.name as string, category: s.category as string,
      })));
      const staffArr = Array.isArray(staffRes) ? staffRes : (staffRes.staff || []);
      setStaffList(staffArr.map((s: Record<string, unknown>) => ({
        id: s.id as number, firstName: s.firstName as string, lastName: s.lastName as string, role: s.role as string,
      })));
      const schoolArr = Array.isArray(schoolRes) ? schoolRes : (schoolRes.schools || []);
      setSchoolList(schoolArr.map((s: Record<string, unknown>) => ({ id: s.id as number, name: s.name as string })));
    } catch {
      toast.error("Failed to load scheduling data");
    }
    setLoading(false);
  }

  const schoolColorMap = useMemo(() => {
    const map = new Map<number, typeof SCHOOL_COLORS[0]>();
    const uniqueSchools = [...new Set(schedules.map(s => s.school_id))];
    uniqueSchools.forEach((id, i) => map.set(id, SCHOOL_COLORS[i % SCHOOL_COLORS.length]));
    return map;
  }, [schedules]);

  const conflictIds = useMemo(() => {
    const set = new Set<number>();
    conflicts.forEach(c => { set.add(c.scheduleAId); set.add(c.scheduleBId); });
    return set;
  }, [conflicts]);

  const filteredSchedules = useMemo(() => {
    return schedules.filter(s => {
      if (filterStaff !== "all" && s.staff_id !== Number(filterStaff)) return false;
      if (filterSchool !== "all" && s.school_id !== Number(filterSchool)) return false;
      if (filterServiceType !== "all" && s.service_type_id !== Number(filterServiceType)) return false;
      return true;
    });
  }, [schedules, filterStaff, filterSchool, filterServiceType]);

  const uniqueStaffInView = useMemo(() => {
    const map = new Map<number, { id: number; name: string; role: string }>();
    filteredSchedules.forEach(s => {
      if (!map.has(s.staff_id)) {
        map.set(s.staff_id, { id: s.staff_id, name: `${s.staffFirstName} ${s.staffLastName}`, role: s.staffRole });
      }
    });
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name));
  }, [filteredSchedules]);

  function scheduleOverlapsExportRange(s: StaffSchedule): boolean {
    if (!exportStartDate && !exportEndDate) return true;
    const effFrom = s.effective_from || null;
    const effTo = s.effective_to || null;
    if (exportStartDate && effTo && effTo < exportStartDate) return false;
    if (exportEndDate && effFrom && effFrom > exportEndDate) return false;
    return true;
  }

  function buildSchedulePrintHtml(): string {
    const dateStr = new Date().toLocaleDateString("en-US", { weekday: undefined, year: "numeric", month: "long", day: "numeric" });
    const rangeStr = exportStartDate || exportEndDate
      ? `${exportStartDate || "earliest"} to ${exportEndDate || "latest"}`
      : "All dates";
    const rangeFilteredSchedules = filteredSchedules.filter(scheduleOverlapsExportRange);
    const staffMap = new Map<number, { name: string; blocks: StaffSchedule[] }>();
    for (const s of rangeFilteredSchedules) {
      if (!staffMap.has(s.staff_id)) {
        staffMap.set(s.staff_id, { name: `${s.staffFirstName} ${s.staffLastName}`, blocks: [] });
      }
      staffMap.get(s.staff_id)!.blocks.push(s);
    }
    const sortedStaff = Array.from(staffMap.values()).sort((a, b) => a.name.localeCompare(b.name));

    const schoolLegend = new Map<number, { name: string; color: typeof SCHOOL_COLOR_HEX[0] }>();
    const uniqueSchools: Array<{ id: number; name: string }> = [];
    for (const s of filteredSchedules) {
      if (!schoolLegend.has(s.school_id)) {
        const color = SCHOOL_COLOR_HEX[schoolLegend.size % SCHOOL_COLOR_HEX.length];
        schoolLegend.set(s.school_id, { name: s.schoolName, color });
        uniqueSchools.push({ id: s.school_id, name: s.schoolName });
      }
    }
    const fallback = SCHOOL_COLOR_HEX[0];

    const rowsHtml = sortedStaff.map(({ name, blocks }) => {
      const cells = WEEKDAYS.map(day => {
        const dayBlocks = blocks.filter(b => b.day_of_week === day);
        if (!dayBlocks.length) return `<td style="background:#f9fafb;border:1px solid #e5e7eb;padding:6px;vertical-align:top;min-width:100px">&nbsp;</td>`;
        const entries = dayBlocks.map(b => {
          const c = schoolLegend.get(b.school_id)?.color || fallback;
          return `<div style="background:${c.bg};border:1px solid ${c.border};border-radius:4px;padding:3px 5px;margin-bottom:3px;font-size:11px">
            <div style="font-weight:600;color:${c.text}">${esc(formatTime(b.start_time))}–${esc(formatTime(b.end_time))}</div>
            <div style="color:${c.text}">${esc(b.schoolName)}</div>
            ${b.label ? `<div style="color:#374151;font-style:italic">${esc(b.label)}</div>` : ""}
          </div>`;
        }).join("");
        return `<td style="border:1px solid #e5e7eb;padding:6px;vertical-align:top;min-width:100px">${entries}</td>`;
      }).join("");
      return `<tr>
        <td style="border:1px solid #e5e7eb;padding:6px 8px;font-weight:500;white-space:nowrap;background:#f9fafb">${esc(name)}</td>
        ${cells}
      </tr>`;
    }).join("");

    const dayHeaders = WEEKDAYS.map(d =>
      `<th style="border:1px solid #e5e7eb;padding:8px;background:#f3f4f6;font-weight:600;text-align:center">${WEEKDAY_LABELS[d]}</th>`
    ).join("");

    const legendItems = uniqueSchools.map(s => {
      const c = schoolLegend.get(s.id)!.color;
      return `<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border:1px solid ${c.border};background:${c.bg};border-radius:4px;font-size:11px;color:${c.text};margin:0 8px 6px 0">
        <span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${c.dot}"></span>
        <span style="font-weight:500">${esc(s.name)}</span>
      </div>`;
    }).join("");
    const legendHtml = uniqueSchools.length
      ? `<div style="margin-top:16px">
          <div style="font-size:12px;font-weight:600;color:#374151;margin-bottom:6px">School color legend</div>
          <div>${legendItems}</div>
        </div>`
      : "";

    return `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Staff Schedule</title>
<style>
  body { font-family: Arial, sans-serif; margin: 20px; color: #111827; }
  h1 { font-size: 18px; margin-bottom: 4px; }
  .meta { font-size: 12px; color: #6b7280; margin-bottom: 16px; }
  table { border-collapse: collapse; width: 100%; }
  @media print { body { margin: 10px; } }
</style>
</head>
<body>
  <h1>Staff Scheduling &amp; Availability</h1>
  <div class="meta">Generated ${dateStr} &bull; Date Range: ${esc(rangeStr)} &bull; ${rangeFilteredSchedules.length} schedule entries</div>
  <table>
    <thead>
      <tr>
        <th style="border:1px solid #e5e7eb;padding:8px;background:#f3f4f6;font-weight:600;text-align:left">Staff Member</th>
        ${dayHeaders}
      </tr>
    </thead>
    <tbody>${rowsHtml}</tbody>
  </table>
  ${legendHtml}
</body>
</html>`;
  }

  function handleExportPdf() {
    if (exportStartDate && exportEndDate && exportStartDate > exportEndDate) {
      toast.error("Start date must be on or before end date");
      return;
    }
    const rangeFiltered = filteredSchedules.filter(scheduleOverlapsExportRange);
    if (!rangeFiltered.length) {
      toast.error("No schedule entries to export for the selected date range");
      return;
    }
    openPrintWindow(buildSchedulePrintHtml());
  }

  async function handleExportCsv() {
    if (exportStartDate && exportEndDate && exportStartDate > exportEndDate) {
      toast.error("Start date must be on or before end date");
      return;
    }
    if (!filteredSchedules.length) {
      toast.error("No schedule entries to export");
      return;
    }
    try {
      const params = new URLSearchParams();
      if (filterStaff !== "all") params.set("staffId", filterStaff);
      if (filterSchool !== "all") params.set("schoolId", filterSchool);
      if (filterServiceType !== "all") params.set("serviceTypeId", filterServiceType);
      if (exportStartDate) params.set("startDate", exportStartDate);
      if (exportEndDate) params.set("endDate", exportEndDate);
      const url = `/api/schedules/export?${params}`;
      const r = await authFetch(url);
      if (!r.ok) throw new Error();
      const blob = await r.blob();
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      const suffix = exportStartDate || exportEndDate
        ? `_${exportStartDate || "earliest"}_to_${exportEndDate || "latest"}`
        : "";
      a.download = `staff-schedules${suffix}.csv`;
      a.click();
      URL.revokeObjectURL(a.href);
    } catch {
      toast.error("Failed to download CSV");
    }
  }

  function openCreate(day?: string) {
    setEditingSchedule(null);
    setFormData({
      staffId: filterStaff !== "all" ? filterStaff : "",
      schoolId: filterSchool !== "all" ? filterSchool : "",
      serviceTypeId: filterServiceType !== "all" ? filterServiceType : "",
      dayOfWeek: day || "monday",
      startTime: "08:00", endTime: "12:00", label: "", notes: "", effectiveFrom: "", effectiveTo: "",
    });
    setShowForm(true);
  }

  function openEdit(s: StaffSchedule) {
    setEditingSchedule(s);
    setFormData({
      staffId: String(s.staff_id),
      schoolId: String(s.school_id),
      serviceTypeId: s.service_type_id ? String(s.service_type_id) : "",
      dayOfWeek: s.day_of_week,
      startTime: s.start_time,
      endTime: s.end_time,
      label: s.label || "",
      notes: s.notes || "",
      effectiveFrom: s.effective_from || "",
      effectiveTo: s.effective_to || "",
    });
    setShowForm(true);
  }

  async function handleSave() {
    if (!formData.staffId || !formData.schoolId) {
      toast.error("Please select a staff member and school"); return;
    }
    setSaving(true);
    try {
      const payload = {
        staffId: Number(formData.staffId),
        schoolId: Number(formData.schoolId),
        serviceTypeId: formData.serviceTypeId ? Number(formData.serviceTypeId) : null,
        dayOfWeek: formData.dayOfWeek,
        startTime: formData.startTime,
        endTime: formData.endTime,
        label: formData.label || null,
        notes: formData.notes || null,
        effectiveFrom: formData.effectiveFrom || null,
        effectiveTo: formData.effectiveTo || null,
      };
      const url = editingSchedule ? `/api/staff-schedules/${editingSchedule.id}` : "/api/staff-schedules";
      const method = editingSchedule ? "PUT" : "POST";
      const r = await authFetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      if (r.status === 409) {
        const d = await r.json();
        toast.error(d.error || "Schedule conflict detected");
        setSaving(false); return;
      }
      if (!r.ok) throw new Error();
      toast.success(editingSchedule ? "Schedule updated" : "Schedule created");
      setShowForm(false);
      loadData();
    } catch {
      toast.error("Failed to save schedule");
    }
    setSaving(false);
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this schedule entry?")) return;
    try {
      const r = await authFetch(`/api/staff-schedules/${id}`, { method: "DELETE" });
      if (!r.ok) throw new Error();
      toast.success("Schedule deleted");
      loadData();
    } catch {
      toast.error("Failed to delete");
    }
  }

  if (loading) {
    return (
      <div className={embedded ? "space-y-4" : "p-6 space-y-4"}>
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-[600px] w-full" />
      </div>
    );
  }

  const actionBar = (
    <div className="flex items-center gap-2">
      {conflicts.length > 0 && (
        <Button variant="outline" size="sm" onClick={() => setShowConflicts(true)} className="text-red-600 border-red-200 hover:bg-red-50">
          <AlertTriangle className="w-3.5 h-3.5 mr-1" /> {conflicts.length} Conflict{conflicts.length !== 1 ? "s" : ""}
        </Button>
      )}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm">
            <Download className="w-3.5 h-3.5 mr-1" /> Export
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-72 p-3">
          <div className="space-y-2 mb-2">
            <p className="text-xs font-semibold text-gray-700">Date range (optional)</p>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="export-start-date" className="text-[11px] text-gray-500">From</Label>
                <Input
                  id="export-start-date"
                  type="date"
                  value={exportStartDate}
                  onChange={(e) => setExportStartDate(e.target.value)}
                  className="h-8 text-xs"
                  data-testid="input-export-start-date"
                />
              </div>
              <div>
                <Label htmlFor="export-end-date" className="text-[11px] text-gray-500">To</Label>
                <Input
                  id="export-end-date"
                  type="date"
                  value={exportEndDate}
                  onChange={(e) => setExportEndDate(e.target.value)}
                  className="h-8 text-xs"
                  data-testid="input-export-end-date"
                />
              </div>
            </div>
            {(exportStartDate || exportEndDate) && (
              <button
                type="button"
                onClick={() => { setExportStartDate(""); setExportEndDate(""); }}
                className="text-[11px] text-emerald-700 hover:underline"
                data-testid="button-clear-export-range"
              >
                Clear date range
              </button>
            )}
          </div>
          <DropdownMenuItem onSelect={(e) => { e.preventDefault(); handleExportPdf(); }} data-testid="button-export-pdf">
            <FileText className="w-4 h-4 mr-2" /> PDF / Print
          </DropdownMenuItem>
          <DropdownMenuItem onSelect={(e) => { e.preventDefault(); handleExportCsv(); }} data-testid="button-export-csv">
            <Sheet className="w-4 h-4 mr-2" /> CSV Download
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      {isAdmin && (
        <Button size="sm" onClick={() => openCreate()} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="w-3.5 h-3.5 mr-1" /> Add Schedule
        </Button>
      )}
    </div>
  );

  const content = (
    <div className="space-y-4">
      {!embedded ? (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-600" />
              Staff Scheduling & Availability
            </h1>
            <p className="text-sm text-gray-500 mt-0.5">
              Cross-building provider schedule — {schedules.length} entries, {conflicts.length} conflict{conflicts.length !== 1 ? "s" : ""}
            </p>
          </div>
          {actionBar}
        </div>
      ) : (
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-gray-500">
            {schedules.length} entries · {conflicts.length} conflict{conflicts.length !== 1 ? "s" : ""}
          </p>
          {actionBar}
        </div>
      )}

      <FilterBar
        staffList={staffList} schoolList={schoolList} serviceTypeList={serviceTypeList}
        filterStaff={filterStaff} setFilterStaff={setFilterStaff}
        filterSchool={filterSchool} setFilterSchool={setFilterSchool}
        filterServiceType={filterServiceType} setFilterServiceType={setFilterServiceType}
      />

      <ScheduleGrid
        uniqueStaffInView={uniqueStaffInView}
        filteredSchedules={filteredSchedules}
        schoolList={schoolList}
        schoolColorMap={schoolColorMap}
        conflictIds={conflictIds}
        isAdmin={isAdmin}
        onCreate={openCreate}
        onEdit={openEdit}
        onDelete={handleDelete}
      />

      {filteredSchedules.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <Card className="p-4">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Providers Scheduled</h3>
            <p className="text-2xl font-bold text-gray-900">{uniqueStaffInView.length}</p>
          </Card>
          <Card className="p-4">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Total Time Blocks</h3>
            <p className="text-2xl font-bold text-gray-900">{filteredSchedules.length}</p>
          </Card>
          <Card className="p-4">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Total Weekly Hours</h3>
            <p className="text-2xl font-bold text-gray-900">
              {(filteredSchedules.reduce((sum, s) => sum + (timeToMinutes(s.end_time) - timeToMinutes(s.start_time)), 0) / 60).toFixed(1)}
            </p>
          </Card>
        </div>
      )}

      {providerSummary && (
        <ProviderSummaryPanel
          providerSummary={providerSummary}
          staffList={staffList}
          filterStaff={filterStaff}
          schoolColorMap={schoolColorMap}
        />
      )}

      {coverageGaps.length > 0 && <CoverageGapsPanel coverageGaps={coverageGaps} />}

      <ScheduleFormDialog
        open={showForm} setOpen={setShowForm}
        editing={!!editingSchedule}
        formData={formData} setFormData={setFormData}
        staffList={staffList} schoolList={schoolList} serviceTypeList={serviceTypeList}
        saving={saving} onSave={handleSave}
      />

      <ConflictsDialog open={showConflicts} setOpen={setShowConflicts} conflicts={conflicts} />
    </div>
  );

  if (embedded) return content;
  return <div className="p-4 md:p-6 max-w-[1400px] mx-auto">{content}</div>;
}
