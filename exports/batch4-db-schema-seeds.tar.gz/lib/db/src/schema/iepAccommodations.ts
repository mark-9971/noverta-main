import { pgTable, text, serial, timestamp, integer, boolean, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { studentsTable } from "./students";

export const iepAccommodationsTable = pgTable("iep_accommodations", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => studentsTable.id),
  iepDocumentId: integer("iep_document_id"),
  category: text("category").notNull().default("instruction"),
  description: text("description").notNull(),
  setting: text("setting"),
  frequency: text("frequency"),
  provider: text("provider"),
  verificationScheduleDays: integer("verification_schedule_days").default(30),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
}, (table) => [
  index("ia_student_idx").on(table.studentId),
  index("ia_iep_doc_idx").on(table.iepDocumentId),
]);

export const insertIepAccommodationSchema = createInsertSchema(iepAccommodationsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertIepAccommodation = z.infer<typeof insertIepAccommodationSchema>;
export type IepAccommodation = typeof iepAccommodationsTable.$inferSelect;
