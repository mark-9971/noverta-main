import { useState, useMemo, useEffect } from "react";
import { useListStudents, useListMinuteProgress, useListSpedStudents, useListSchools, useListStaff, createStudent } from "@workspace/api-client-react";
import type { ListStudents200 } from "@workspace/api-client-react";

type StudentRow = ListStudents200["data"][number] & {
  schoolName?: string | null;
  programName?: string | null;
  caseManagerFirst?: string | null;
  caseManagerLast?: string | null;
};
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { MiniProgressRing } from "@/components/ui/progress-ring";
import { ErrorBanner } from "@/components/ui/error-banner";
import { Search, ChevronRight, ChevronLeft, GraduationCap, BookOpen, Plus, AlertCircle, Archive, Phone, CalendarDays, Users } from "lucide-react";
import { EmptyState, EmptyStateStep, EmptyStateHeading, EmptyStateDetail } from "@/components/ui/empty-state";
import { Link } from "wouter";
import { StudentQuickView } from "@/components/student-quick-view";
import { RISK_CONFIG, RISK_PRIORITY_ORDER } from "@/lib/constants";
import { useSchoolContext } from "@/lib/school-context";
import { useRole } from "@/lib/role-context";
import { useSisConnection } from "@/lib/use-sis-connection";
import { useSchoolYears } from "@/lib/use-school-years";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

type TypeFilter = "all" | "sped" | "gen_ed";
type StatusFilter = "active" | "inactive" | "all";
type RiskTier = "all" | "critical" | "at_risk" | "on_track";

const RISK_TIER_STATUSES: Record<RiskTier, string[]> = {
  all: [],
  critical: ["out_of_compliance"],
  at_risk: ["at_risk", "slightly_behind"],
  on_track: ["on_track"],
};

const PAGE_SIZE = 100;

export default function Students() {
  const [search, setSearch] = useState("");
  const [riskFilter, setRiskFilter] = useState<RiskTier>("all");
  const [serviceTypeFilter, setServiceTypeFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<TypeFilter>("all");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("active");
  const [caseManagerFilter, setCaseManagerFilter] = useState<string>("all");
  const [gradeFilter, setGradeFilter] = useState<string>("all");
  const [schoolFilter, setSchoolFilter] = useState<string>("all");
  const [missingFilter, setMissingFilter] = useState<"all" | "no_services">("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const [addSaving, setAddSaving] = useState(false);
  const [addForm, setAddForm] = useState({ firstName: "", lastName: "", grade: "", schoolId: "", externalId: "", dateOfBirth: "", hasIep: "" as "" | "yes" | "no" });

  const { filterParams } = useSchoolContext();
  const { role } = useRole();
  const { years: schoolYears, activeYear } = useSchoolYears();
  const [selectedYearId, setSelectedYearId] = useState<string>("all");

  // Default to active year once school years are loaded
  useEffect(() => {
    if (activeYear && selectedYearId === "all") setSelectedYearId(String(activeYear.id));
  }, [activeYear]);

  const { data: students, isLoading, isError, refetch } = useListStudents({
    ...filterParams,
    limit: PAGE_SIZE,
    offset: (currentPage - 1) * PAGE_SIZE,
    status: statusFilter,
    ...(selectedYearId !== "all" ? { schoolYearId: Number(selectedYearId) } : {}),
    ...(caseManagerFilter !== "all" ? { caseManagerId: Number(caseManagerFilter) } : {}),
    ...(gradeFilter !== "all" ? { grade: gradeFilter } : {}),
    ...(schoolFilter !== "all" ? { schoolId: Number(schoolFilter) } : {}),
    // Push risk-tier filtering into the API so the paginated `total` reflects
    // only matching students (otherwise the footer would show the unfiltered
    // student count even when a tier chip is active).
    ...(riskFilter !== "all" ? { riskStatus: RISK_TIER_STATUSES[riskFilter].join(",") } : {}),
  } as any);
  const { data: progress } = useListMinuteProgress({ ...filterParams } as any);
  const { data: spedStudentsRaw } = useListSpedStudents(filterParams as any);
  const { data: schoolsData } = useListSchools();
  const { data: staffData } = useListStaff(filterParams as any);
  const schoolsList = (Array.isArray(schoolsData) ? schoolsData : []) as any[];
  const caseManagers = (Array.isArray(staffData) ? staffData : [])
    .filter((s: any) => !s.role || /case|coord|admin|teacher|spec/i.test(s.role || ""))
    .map((s: any) => ({ id: s.id, label: `${s.lastName ?? ""}, ${s.firstName ?? ""}`.trim() || `Staff ${s.id}` }))
    .sort((a: any, b: any) => a.label.localeCompare(b.label));

  const isAdmin = role === "admin";
  // Source-of-truth gate for SIS-owned data (demographics, guardians,
  // medical alerts, etc.). Hides manual-entry affordances once a real
  // SIS connection is live so Trellis never contradicts the SIS of record.
  const sis = useSisConnection();
  const hasSIS = sis.connected;

  async function handleAddStudent() {
    if (!addForm.firstName || !addForm.lastName) { toast.error("First and last name are required"); return; }
    setAddSaving(true);
    try {
      await createStudent({
        firstName: addForm.firstName,
        lastName: addForm.lastName,
        grade: addForm.grade || null,
        schoolId: addForm.schoolId ? Number(addForm.schoolId) : null,
        externalId: addForm.externalId || null,
        dateOfBirth: addForm.dateOfBirth || null,
        placementType: addForm.hasIep === "yes" ? "iep" : addForm.hasIep === "no" ? "gen_ed" : null,
        status: "active",
      });
      toast.success(`${addForm.firstName} ${addForm.lastName} added`);
      setAddDialogOpen(false);
      setAddForm({ firstName: "", lastName: "", grade: "", schoolId: "", externalId: "", dateOfBirth: "", hasIep: "" });
      refetch();
    } catch { toast.error("Failed to add student"); }
    setAddSaving(false);
  }

  const spedIds = new Set<number>((Array.isArray(spedStudentsRaw) ? spedStudentsRaw : []).map((s: any) => s.id));

  const studentList: StudentRow[] = (students?.data ?? []) as StudentRow[];
  const totalStudents: number = students?.total ?? 0;
  const studentHasMore: boolean = students?.hasMore ?? false;
  const totalPages = totalStudents > 0 ? Math.ceil(totalStudents / PAGE_SIZE) : 1;
  const progressList = (progress as any[]) ?? [];
  const loading = isLoading;

  // Reset to page 1 whenever the filter criteria change.
  useEffect(() => {
    setCurrentPage(1);
  }, [statusFilter, riskFilter, typeFilter, caseManagerFilter, gradeFilter, schoolFilter, missingFilter, serviceTypeFilter, selectedYearId, JSON.stringify(filterParams)]);

  const priorityOrder = RISK_PRIORITY_ORDER;
  const studentRisk: Record<number, string> = {};
  for (const p of progressList) {
    const current = studentRisk[p.studentId];
    if (!current || priorityOrder.indexOf(p.riskStatus) < priorityOrder.indexOf(current)) {
      studentRisk[p.studentId] = p.riskStatus;
    }
  }

  const studentMinutes: Record<number, { delivered: number; required: number }> = {};
  for (const p of progressList) {
    if (!studentMinutes[p.studentId]) studentMinutes[p.studentId] = { delivered: 0, required: 0 };
    studentMinutes[p.studentId].delivered += p.deliveredMinutes;
    studentMinutes[p.studentId].required += p.requiredMinutes;
  }

  const studentServiceTypeIds: Record<number, Set<number>> = {};
  for (const p of progressList) {
    if (p.serviceTypeId != null) {
      if (!studentServiceTypeIds[p.studentId]) studentServiceTypeIds[p.studentId] = new Set();
      studentServiceTypeIds[p.studentId].add(p.serviceTypeId);
    }
  }

  const serviceTypeOptions = (() => {
    const seen = new Map<number, string>();
    for (const p of progressList) {
      if (p.serviceTypeId != null && p.serviceTypeName) seen.set(Number(p.serviceTypeId), String(p.serviceTypeName));
    }
    return Array.from(seen.entries())
      .map(([id, label]) => ({ id, label }))
      .sort((a, b) => a.label.localeCompare(b.label));
  })();

  // District-wide totals for the header/type-filter chips. studentList only
  // holds the current page (PAGE_SIZE=100) and `students.total` is scoped to
  // the active/inactive filter, so neither matches the risk-tier chips (which
  // count the full district via the minute-progress list). Source the SPED
  // count from the district-wide SPED endpoint and derive Gen Ed from the
  // unique studentIds present in the progress list, so all three numbers in
  // the header agree with "All (N)" on the risk row.
  const districtSpedTotal: number = Array.isArray(spedStudentsRaw) ? spedStudentsRaw.length : 0;
  let districtGenEdTotal = 0;
  for (const idStr of Object.keys(studentRisk)) {
    if (!spedIds.has(Number(idStr))) districtGenEdTotal++;
  }
  const districtTotalStudents: number = districtSpedTotal + districtGenEdTotal;
  const spedCount = districtSpedTotal;
  const genEdCount = districtGenEdTotal;

  const filtered = useMemo(() => {
    return studentList.filter(s => {
      const matchSearch = search.trim() === "" ||
        `${s.firstName} ${s.lastName}`.toLowerCase().includes(search.toLowerCase());
      const isSped = spedIds.has(s.id);
      const matchType = typeFilter === "all" || (typeFilter === "sped" && isSped) || (typeFilter === "gen_ed" && !isSped);
      // Risk filtering is now performed server-side (see useListStudents above)
      // so the API's `total` matches the rows we render and the pagination
      // footer stays accurate. Re-applying a client-side risk match here would
      // re-introduce a mismatch (the server treats `completed`/`no_data` as
      // on_track, while the client tier mapping does not).
      const matchServiceType = serviceTypeFilter === "all" ||
        (studentServiceTypeIds[s.id]?.has(Number(serviceTypeFilter)) ?? false);
      const matchMissing = missingFilter === "all" ||
        (missingFilter === "no_services" && isSped && !studentMinutes[s.id]);
      return matchSearch && matchType && matchServiceType && matchMissing;
    });
  }, [studentList, search, typeFilter, serviceTypeFilter, spedIds, studentServiceTypeIds, missingFilter, studentMinutes]);

  // Tier counts are derived from the full district-wide minute-progress list
  // (not the paginated, risk-filtered studentList) so the chips keep showing
  // accurate counts for every tier even while one tier is selected.
  const tierCounts = useMemo(() => {
    let critical = 0, at_risk = 0, on_track = 0;
    for (const idStr of Object.keys(studentRisk)) {
      const sid = Number(idStr);
      const isSped = spedIds.has(sid);
      if (typeFilter === "sped" && !isSped) continue;
      if (typeFilter === "gen_ed" && isSped) continue;
      const r = studentRisk[sid];
      if (r === "out_of_compliance") critical++;
      else if (r === "at_risk" || r === "slightly_behind") at_risk++;
      else on_track++;
    }
    return { critical, at_risk, on_track, all: critical + at_risk + on_track };
  }, [studentRisk, typeFilter, spedIds]);

  return (
    <div className="p-4 md:p-6 lg:p-8 max-w-[1200px] mx-auto space-y-4 md:space-y-6">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl md:text-2xl font-bold text-gray-800 tracking-tight">Students</h1>
            {activeYear && (
              <span className="flex items-center gap-1 px-2 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-700 text-[11px] font-medium rounded-full">
                <CalendarDays className="w-3 h-3" /> {activeYear.label}
              </span>
            )}
          </div>
          <p className="text-xs md:text-sm text-gray-400 mt-1">
            {districtTotalStudents} total students · {spedCount} SPED · {genEdCount} Gen Ed
          </p>
        </div>
        {isAdmin && !hasSIS && (
          <button
            onClick={() => { setAddForm({ firstName: "", lastName: "", grade: "", schoolId: "", externalId: "", dateOfBirth: "", hasIep: "" }); setAddDialogOpen(true); }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-[12px] font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex-shrink-0"
          >
            <Plus className="w-3.5 h-3.5" /> Add Student
          </button>
        )}
      </div>

      {isAdmin && !hasSIS && (
        <div className="flex items-start gap-2.5 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-[12px] text-gray-600">
          <AlertCircle className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
          <div>
            <span className="font-medium text-gray-700">No SIS connected.</span> Student demographics are managed manually. Use the "Add Student" button above or{" "}
            <Link href="/import-data" className="text-emerald-700 hover:text-emerald-800 underline">import from CSV</Link>{" "}
            to add students in bulk.
          </div>
        </div>
      )}
      {isAdmin && hasSIS && (
        <div className="flex items-start gap-2.5 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-[12px] text-gray-600">
          <AlertCircle className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
          <div>
            <span className="font-medium text-gray-700">SIS connected.</span> Student records sync automatically. To add a student manually,{" "}
            <Link href="/import-data" className="text-emerald-700 hover:text-emerald-800 underline">use the SIS or CSV import</Link>{" "}
            to avoid duplicate records.
          </div>
        </div>
      )}

      <div className="flex gap-2 flex-wrap">
        {([
          { key: "all" as TypeFilter, label: "All Students", count: districtTotalStudents, icon: null },
          { key: "sped" as TypeFilter, label: "SPED", count: spedCount, icon: GraduationCap },
          { key: "gen_ed" as TypeFilter, label: "Gen Ed", count: genEdCount, icon: BookOpen },
        ]).map(t => (
          <button
            key={t.key}
            aria-pressed={typeFilter === t.key}
            onClick={() => setTypeFilter(typeFilter === t.key && t.key !== "all" ? "all" : t.key)}
            className={`px-3.5 py-1.5 rounded-full text-[12px] font-medium transition-all flex items-center gap-1.5 ${
              typeFilter === t.key ? "bg-emerald-700 text-white" : "bg-white text-gray-500 border border-gray-200 hover:border-gray-300"
            }`}
          >
            {t.icon && <t.icon className="w-3.5 h-3.5" />}
            {t.label} ({t.count})
          </button>
        ))}
        <div className="w-px bg-gray-200 mx-1 self-stretch" />
        {([
          { key: "active" as StatusFilter, label: "Active" },
          { key: "inactive" as StatusFilter, label: "Inactive", icon: Archive },
          { key: "all" as StatusFilter, label: "All Statuses" },
        ]).map(s => (
          <button
            key={s.key}
            aria-pressed={statusFilter === s.key}
            onClick={() => setStatusFilter(s.key)}
            className={`px-3.5 py-1.5 rounded-full text-[12px] font-medium transition-all flex items-center gap-1.5 ${
              statusFilter === s.key
                ? s.key === "inactive" ? "bg-amber-600 text-white" : "bg-gray-700 text-white"
                : "bg-white text-gray-500 border border-gray-200 hover:border-gray-300"
            }`}
          >
            {s.key === "inactive" && <Archive className="w-3 h-3" />}
            {s.label}
          </button>
        ))}
      </div>

      {/* Risk-tier chips + service-type dropdown */}
      <div className="flex gap-2 flex-wrap items-center">
        {(
          [
            { key: "all" as RiskTier, label: "All", count: tierCounts.all },
            { key: "critical" as RiskTier, label: "Critical", count: tierCounts.critical },
            { key: "at_risk" as RiskTier, label: "At Risk", count: tierCounts.at_risk },
            { key: "on_track" as RiskTier, label: "On Track", count: tierCounts.on_track },
          ] as { key: RiskTier; label: string; count: number }[]
        ).map(t => {
          const accentClass =
            t.key === "critical" ? (riskFilter === t.key ? "bg-red-600 text-white border-transparent" : "border-red-200 text-red-700 hover:border-red-300")
            : t.key === "at_risk" ? (riskFilter === t.key ? "bg-amber-600 text-white border-transparent" : "border-amber-200 text-amber-700 hover:border-amber-300")
            : t.key === "on_track" ? (riskFilter === t.key ? "bg-emerald-600 text-white border-transparent" : "border-emerald-200 text-emerald-700 hover:border-emerald-300")
            : (riskFilter === "all" ? "bg-gray-800 text-white border-transparent" : "border-gray-200 text-gray-500 hover:border-gray-300");
          return (
            <button
              key={t.key}
              aria-pressed={riskFilter === t.key}
              onClick={() => setRiskFilter(riskFilter === t.key && t.key !== "all" ? "all" : t.key)}
              className={`px-3.5 py-1.5 rounded-full text-[12px] font-medium border transition-all bg-white ${accentClass}`}
            >
              {t.label} ({t.count})
            </button>
          );
        })}
        {serviceTypeOptions.length > 0 && (
          <Select value={serviceTypeFilter} onValueChange={setServiceTypeFilter}>
            <SelectTrigger className="h-9 text-[12px] bg-white w-[170px]">
              <SelectValue placeholder="All service types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All service types</SelectItem>
              {serviceTypeOptions.map(t => (
                <SelectItem key={t.id} value={String(t.id)}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input className="pl-10 h-10 text-[13px] bg-white" placeholder="Search by student name..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        {schoolYears.length > 0 && (
          <Select value={selectedYearId} onValueChange={v => setSelectedYearId(v)}>
            <SelectTrigger className="h-10 text-[12px] bg-white w-[140px]">
              <SelectValue placeholder="School Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Years</SelectItem>
              {[...schoolYears].reverse().map(y => (
                <SelectItem key={y.id} value={String(y.id)}>{y.label}{y.isActive ? " (Active)" : ""}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
        {schoolsList.length > 1 && (
          <Select value={schoolFilter} onValueChange={setSchoolFilter}>
            <SelectTrigger className="h-10 text-[12px] bg-white w-[150px]"><SelectValue placeholder="All schools" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All schools</SelectItem>
              {schoolsList.map((sch: any) => <SelectItem key={sch.id} value={String(sch.id)}>{sch.name}</SelectItem>)}
            </SelectContent>
          </Select>
        )}
        <Select value={caseManagerFilter} onValueChange={setCaseManagerFilter}>
          <SelectTrigger className="h-10 text-[12px] bg-white w-[170px]"><SelectValue placeholder="All case managers" /></SelectTrigger>
          <SelectContent className="max-h-[300px]">
            <SelectItem value="all">All case managers</SelectItem>
            {caseManagers.map(cm => <SelectItem key={cm.id} value={String(cm.id)}>{cm.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={gradeFilter} onValueChange={setGradeFilter}>
          <SelectTrigger className="h-10 text-[12px] bg-white w-[110px]"><SelectValue placeholder="All grades" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All grades</SelectItem>
            {["PK", "K", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"].map(g =>
              <SelectItem key={g} value={g}>Grade {g}</SelectItem>
            )}
          </SelectContent>
        </Select>
        <button
          aria-pressed={missingFilter === "no_services"}
          onClick={() => setMissingFilter(missingFilter === "no_services" ? "all" : "no_services")}
          className={`h-10 px-3 rounded-md text-[12px] font-medium border transition-colors ${
            missingFilter === "no_services"
              ? "bg-amber-50 border-amber-300 text-amber-800"
              : "bg-white border-gray-200 text-gray-500 hover:border-gray-300"
          }`}
          title="SPED students with no active service requirements"
        >
          No services tracked
        </button>
      </div>

      <div className="space-y-2">
        {isError && studentList.length === 0 ? (
          <ErrorBanner message="Failed to load student list." onRetry={() => refetch()} />
        ) : loading ? (
          [...Array(8)].map((_, i) => <Skeleton key={i} className="w-full h-[72px] rounded-xl" />)
        ) : filtered.length === 0 ? (
          role === "admin" ? (
            <EmptyState
              icon={Users}
              title="No Students in Your Roster"
              compact
              action={{ label: "Add a Student", href: "/students/new" }}
              secondaryAction={{ label: "Import from SIS", href: "/sis-settings", variant: "outline" }}
            >
              <EmptyStateDetail>
                Your student roster is the foundation of SPED compliance tracking. Every student with an active IEP needs to be here so Trellis can monitor service delivery, flag shortfalls, and calculate compensatory exposure.
              </EmptyStateDetail>
              <EmptyStateHeading>Get started:</EmptyStateHeading>
              <EmptyStateStep number={1}>Connect your Student Information System (SIS) under Settings to auto-import students, schools, and enrollments.</EmptyStateStep>
              <EmptyStateStep number={2}>Or add students manually — you'll need their name, grade, school, and disability category.</EmptyStateStep>
              <EmptyStateStep number={3}>Once students are added, create IEP documents and service requirements for each student to begin tracking.</EmptyStateStep>
            </EmptyState>
          ) : (
            <EmptyState
              icon={Users}
              title="No students match your filters"
              description="Try adjusting the search, school, or year filters above."
              compact
            />
          )
        ) : filtered.map(s => {
          const isSped = spedIds.has(s.id);
          const risk = studentRisk[s.id] ?? "on_track";
          const cfg = RISK_CONFIG[risk] ?? RISK_CONFIG.on_track;
          const mins = studentMinutes[s.id] ?? { delivered: 0, required: 0 };
          const pct = mins.required > 0 ? Math.round((mins.delivered / mins.required) * 100) : 0;

          return (
            <Link key={s.id} href={`/students/${s.id}`}>
              <Card className="hover:shadow-sm transition-all cursor-pointer group">
                <div className="flex items-center gap-4 p-4">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-[13px] font-bold flex-shrink-0 ${
                    isSped ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-600"
                  }`}>
                    {s.firstName?.[0]}{s.lastName?.[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-[14px] font-semibold text-gray-800">{s.firstName} {s.lastName}</p>
                      <StudentQuickView
                        studentId={s.id}
                        studentName={`${s.firstName} ${s.lastName}`}
                        grade={s.grade ?? null}
                        trigger={
                          <span className="p-1 rounded hover:bg-gray-100 transition-colors" title="Quick view: emergency contacts &amp; alerts">
                            <Phone className="w-3 h-3 text-gray-400 hover:text-emerald-600" />
                          </span>
                        }
                      />
                      <Badge variant="outline" className={`text-[10px] py-0 px-1.5 ${
                        isSped ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-gray-50 text-gray-500 border-gray-200"
                      }`}>
                        {isSped ? "SPED" : "Gen Ed"}
                      </Badge>
                      {s.status === "inactive" && (
                        <Badge variant="outline" className="text-[10px] py-0 px-1.5 bg-amber-50 text-amber-700 border-amber-200">
                          Inactive
                        </Badge>
                      )}
                      {(s as { source?: string | null }).source === "pilot_csv" && (
                        <Badge
                          variant="outline"
                          title="Imported via the pilot kickoff CSV wizard — will be reconciled with SIS sync without duplicating"
                          className="text-[10px] py-0 px-1.5 bg-emerald-50 text-emerald-700 border-emerald-200"
                          data-testid={`badge-pilot-csv-student-${s.id}`}
                        >
                          CSV
                        </Badge>
                      )}
                    </div>
                    <p className="text-[12px] text-gray-400">
                      Grade {s.grade}{s.caseManagerId ? ` · CM #${s.caseManagerId}` : ""}
                      {s.status === "inactive" && s.withdrawnAt
                        ? <> · <span className="text-amber-600">Withdrawn {new Date(s.withdrawnAt).toLocaleDateString("en-US", { month: "short", year: "numeric" })}</span></>
                        : s.enrolledAt
                          ? ` · Enrolled ${new Date(s.enrolledAt).toLocaleDateString("en-US", { month: "short", year: "numeric" })}`
                          : null}
                    </p>
                  </div>
                  {isSped ? (
                    <>
                      <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full border ${cfg.bg} ${cfg.color} flex-shrink-0 hidden md:inline-flex`}>
                        {cfg.label}
                      </span>
                      <div className="flex items-center gap-2 md:gap-3 flex-shrink-0">
                        <MiniProgressRing value={pct} size={36} strokeWidth={3.5} color={cfg.ringColor} />
                        <div className="text-right w-14 md:w-20">
                          <p className="text-[13px] font-bold text-gray-700">{pct}%</p>
                          <p className="text-[10px] text-gray-400 hidden sm:block">{mins.delivered}/{mins.required}</p>
                        </div>
                      </div>
                    </>
                  ) : (
                    <span className="text-[11px] font-semibold px-2.5 py-1 rounded-full border bg-gray-50 text-gray-500 border-gray-200 flex-shrink-0 hidden md:inline-flex">
                      General Education
                    </span>
                  )}
                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-gray-500 transition-colors flex-shrink-0" />
                </div>
              </Card>
            </Link>
          );
        })}
      </div>

      {/* Pagination controls — shown when there is more than one page of students */}
      {(totalStudents > PAGE_SIZE || currentPage > 1) && (
        <div className="flex items-center justify-between pt-2 pb-1">
          <p className="text-[12px] text-gray-500">
            Showing {(currentPage - 1) * PAGE_SIZE + 1}–{Math.min(currentPage * PAGE_SIZE, totalStudents)} of {totalStudents.toLocaleString()} students
          </p>
          <div className="flex items-center gap-1.5">
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-[12px] px-2"
              disabled={currentPage <= 1 || isLoading}
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            >
              <ChevronLeft className="w-3.5 h-3.5 mr-0.5" /> Prev
            </Button>
            <span className="text-[12px] text-gray-500 px-1">
              Page {currentPage} of {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-[12px] px-2"
              disabled={!studentHasMore || isLoading}
              onClick={() => setCurrentPage(p => p + 1)}
            >
              Next <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
            </Button>
          </div>
        </div>
      )}

      <Dialog open={addDialogOpen} onOpenChange={v => { if (!v) setAddDialogOpen(false); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[15px] font-semibold text-gray-800">Add Student</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-1">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-[12px] font-medium text-gray-600">First Name <span className="text-red-400">*</span></Label>
                <Input value={addForm.firstName} onChange={e => setAddForm(f => ({ ...f, firstName: e.target.value }))} className="h-9 text-[13px]" placeholder="First name" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px] font-medium text-gray-600">Last Name <span className="text-red-400">*</span></Label>
                <Input value={addForm.lastName} onChange={e => setAddForm(f => ({ ...f, lastName: e.target.value }))} className="h-9 text-[13px]" placeholder="Last name" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-[12px] font-medium text-gray-600">Date of Birth</Label>
                <Input type="date" value={addForm.dateOfBirth} onChange={e => setAddForm(f => ({ ...f, dateOfBirth: e.target.value }))} className="h-9 text-[13px]" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px] font-medium text-gray-600">Grade</Label>
                <Select value={addForm.grade} onValueChange={v => setAddForm(f => ({ ...f, grade: v }))}>
                  <SelectTrigger className="h-9 text-[13px] bg-white"><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>
                    {["PK", "K", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"].map(g => (
                      <SelectItem key={g} value={g} className="text-[13px]">{g}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-[12px] font-medium text-gray-600">School</Label>
                <Select value={addForm.schoolId} onValueChange={v => setAddForm(f => ({ ...f, schoolId: v }))}>
                  <SelectTrigger className="h-9 text-[13px] bg-white"><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>
                    {schoolsList.map((sch: any) => (
                      <SelectItem key={sch.id} value={String(sch.id)} className="text-[13px]">{sch.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px] font-medium text-gray-600">IEP Status</Label>
                <div className="flex gap-1 h-9">
                  {([{ key: "yes" as const, label: "Yes" }, { key: "no" as const, label: "No" }]).map(opt => (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => setAddForm(f => ({ ...f, hasIep: f.hasIep === opt.key ? "" : opt.key }))}
                      className={`flex-1 rounded-md text-[13px] font-medium transition-colors border ${
                        addForm.hasIep === opt.key
                          ? opt.key === "yes" ? "bg-emerald-50 border-emerald-300 text-emerald-700" : "bg-gray-50 border-gray-300 text-gray-700"
                          : "bg-white border-gray-200 text-gray-400 hover:border-gray-300"
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px] font-medium text-gray-600">External ID</Label>
              <Input value={addForm.externalId} onChange={e => setAddForm(f => ({ ...f, externalId: e.target.value }))} className="h-9 text-[13px]" placeholder="SIS ID (optional)" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" size="sm" onClick={() => setAddDialogOpen(false)} disabled={addSaving}>Cancel</Button>
            <Button size="sm" onClick={handleAddStudent} disabled={addSaving} className="bg-emerald-600 hover:bg-emerald-700 text-white">
              {addSaving ? "Adding…" : "Add Student"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
